# Section A: DATA COLLECTION


```python
import requests
import numpy as np
import urllib.request
import pandas as pd
import csv
from csv import writer
import bs4
from bs4 import BeautifulSoup
import seaborn as sns
sns.set_style("darkgrid")
import matplotlib.pyplot as plt
%matplotlib inline
plt.style.use('fivethirtyeight')  
import warnings
warnings.filterwarnings('ignore')
```

## A-Web scrapping from NCDC site


```python
url = "https://covid19.ncdc.gov.ng/"
headers = {
    'User Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53"
}
```


```python
r = requests.get(url, {'headers': headers})
covid = bs4.BeautifulSoup(r.text, 'html.parser')
```


```python
covid.find_all()
```




    [<html lang="en">
     <meta content="text/html;charset=utf-8" http-equiv="content-type"/>
     <head>
     <title>NCDC Coronavirus COVID-19 Microsite</title>
     <!--[if lt IE 11]>
         	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
         	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
         	<![endif]-->
     <meta charset="utf-8"/>
     <meta content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" name="viewport"/>
     <meta content="IE=edge" http-equiv="X-UA-Compatible">
     <meta content="" name="description">
     <meta content="" name="keywords"/>
     <meta content="Codedthemes" name="author">
     <!-- Google Tag Manager -->
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>
     <!-- End Google Tag Manager -->
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>
     <link href="/static/css/style.css " rel="stylesheet"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link></meta></meta></meta></head>
     <body class="">
     <div class="loader-bg">
     <div class="loader-track">
     <div class="loader-fill"></div>
     </div>
     </div>
     <style>
       .pcoded-header.header-green a:hover, .pcoded-header.header-green dropdown-toggle {
         color:#FFC82D;
     }
     </style>
     <nav class="pcoded-navbar menupos-fixed menu-light">
     <div class="navbar-wrapper">
     <div class="navbar-content scroll-div">
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>
     </div>
     </div>
     </nav>
     <header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed header-green">
     <div class="m-header">
     <a class="mobile-menu" href="#!" id="mobile-collapse"><span></span></a>
     <a class="b-brand" href="#!">
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>
     </a>
     <a class="mob-toggler" href="#!">
     <i class="feather icon-more-vertical"></i>
     </a>
     </div>
     <div class="collapse navbar-collapse">
     <ul class="navbar-nav mr-auto">
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>
     </ul>
     <ul class="navbar-nav ml-auto">
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>
     <li>
     </li>
     </ul>
     </div>
     </header>
     <div class="pcoded-main-container">
     <div class="pcoded-content">
     <div class="page-header">
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row card-header">
     <h4>Updates</h4>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     <style>
     	.footer-content{
     	
     		padding: 30px;
     		
     	}
     	.footer-content a{
     		color: white;
     	}
     	.social{
     		color: #FFF;
     	}
     	.footer-logo a{
     		color: #FFF;
     	}
     </style>
     <style>
     footer {
       background-color: yellow;
     }
     
     @media only screen and (max-width: 600px) {
       footer {
         background-color: lightblue;
       }
     }
     </style>
     <div class="footer-area foomter" style="background-color: #138750">
     <div class="container">
     <div class="row">
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     <style>
         #connectcenter {
           background-color: #ffC82D;
           margin-top: -20px;
         }
         #connectcenter img {
          
           margin: 0px 16px 0px 0px;
           width: 32px !important;
         }
         #connectcenter li {
           font-size: 1.2em;
           
         }
     	   a#social{text-decoration: none;
     	  color: #444444;}
     
         .img-thumbnail{
           background-color: none;
     
         }
         
      </style>
     <div class="yellow darken-4 white-text foomter" id="connectcenter" style="border-top: solid 1px white;padding-left: 20px">
     <h3>Connect Centre</h3>
     <div class="row">
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>Toll Free Number: <b>6232</b>
     </div>
     <div class="col-md-4">
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>
     </div>
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>SMS Number: <b>+234809 955 5577</b>
     </div>
     </div>
     </div>
     <script src="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.js"></script>
     <script src="/static/js/vendor-all.min.js"></script>
     <script crossorigin="anonymous" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
     <script src="/static/js/pcoded.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js" type="text/javascript"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js" type="text/javascript"></script>
     <script src="/static/js/app.js" type="text/javascript"></script>
     <!-- Global site tag (gtag.js) - Google Analytics -->
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-X0FT1KY27K"></script>
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'G-X0FT1KY27K');
     
         </script>
     <!-- Global site tag (gtag.js) - Google Analytics -->
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-161734978-1"></script>
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'UA-161734978-1');
         </script>
     <script>
           function init() {
     var vidDefer = document.getElementsByTagName('iframe');
     for (var i=0; i<vidDefer.length; i++) {
     if(vidDefer[i].getAttribute('data-src')) {
     vidDefer[i].setAttribute('src',vidDefer[i].getAttribute('data-src'));
     } } }
     window.onload = init;
       </script>
     <script>
       $(document).ready(function(){
           $("#myModal").modal('show');
       });
     
     
     </script>
     </body>
     </html>,
     <meta content="text/html;charset=utf-8" http-equiv="content-type"/>,
     <head>
     <title>NCDC Coronavirus COVID-19 Microsite</title>
     <!--[if lt IE 11]>
         	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
         	<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
         	<![endif]-->
     <meta charset="utf-8"/>
     <meta content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" name="viewport"/>
     <meta content="IE=edge" http-equiv="X-UA-Compatible">
     <meta content="" name="description">
     <meta content="" name="keywords"/>
     <meta content="Codedthemes" name="author">
     <!-- Google Tag Manager -->
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>
     <!-- End Google Tag Manager -->
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>
     <link href="/static/css/style.css " rel="stylesheet"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link></meta></meta></meta></head>,
     <title>NCDC Coronavirus COVID-19 Microsite</title>,
     <meta charset="utf-8"/>,
     <meta content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" name="viewport"/>,
     <meta content="IE=edge" http-equiv="X-UA-Compatible">
     <meta content="" name="description">
     <meta content="" name="keywords"/>
     <meta content="Codedthemes" name="author">
     <!-- Google Tag Manager -->
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>
     <!-- End Google Tag Manager -->
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>
     <link href="/static/css/style.css " rel="stylesheet"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link></meta></meta></meta>,
     <meta content="" name="description">
     <meta content="" name="keywords"/>
     <meta content="Codedthemes" name="author">
     <!-- Google Tag Manager -->
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>
     <!-- End Google Tag Manager -->
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>
     <link href="/static/css/style.css " rel="stylesheet"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link></meta></meta>,
     <meta content="" name="keywords"/>,
     <meta content="Codedthemes" name="author">
     <!-- Google Tag Manager -->
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>
     <!-- End Google Tag Manager -->
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>
     <link href="/static/css/style.css " rel="stylesheet"/>
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link></meta>,
     <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
       new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
       j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
       'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
       })(window,document,'script','dataLayer','GTM-PLDLB6N');</script>,
     <link href="/static/img/index.ico" rel="icon" type="image/x-icon"/>,
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>,
     <link href="https://cdn.jsdelivr.net/npm/line-awesome@1.3.0/dist/line-awesome/css/line-awesome.min.css" rel="stylesheet" type="text/css"/>,
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet" type="text/css"/>,
     <link href="/static/css/style.css " rel="stylesheet"/>,
     <link href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet" type="text/css"/>,
     <style>
             html,
             body {
               margin: 0;
               height: 100%;
               width: 100%;
     
               box-sizing: border-box;
             }
          
             #travel{
           width: 600px;
             }
           
             @media only screen and (max-device-width: 480px) {
               #travel{
           width: 350px;
             }
           
           }
           </style>,
     <link href="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.css" rel="stylesheet">
     </link>,
     <body class="">
     <div class="loader-bg">
     <div class="loader-track">
     <div class="loader-fill"></div>
     </div>
     </div>
     <style>
       .pcoded-header.header-green a:hover, .pcoded-header.header-green dropdown-toggle {
         color:#FFC82D;
     }
     </style>
     <nav class="pcoded-navbar menupos-fixed menu-light">
     <div class="navbar-wrapper">
     <div class="navbar-content scroll-div">
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>
     </div>
     </div>
     </nav>
     <header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed header-green">
     <div class="m-header">
     <a class="mobile-menu" href="#!" id="mobile-collapse"><span></span></a>
     <a class="b-brand" href="#!">
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>
     </a>
     <a class="mob-toggler" href="#!">
     <i class="feather icon-more-vertical"></i>
     </a>
     </div>
     <div class="collapse navbar-collapse">
     <ul class="navbar-nav mr-auto">
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>
     </ul>
     <ul class="navbar-nav ml-auto">
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>
     <li>
     </li>
     </ul>
     </div>
     </header>
     <div class="pcoded-main-container">
     <div class="pcoded-content">
     <div class="page-header">
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row card-header">
     <h4>Updates</h4>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     <style>
     	.footer-content{
     	
     		padding: 30px;
     		
     	}
     	.footer-content a{
     		color: white;
     	}
     	.social{
     		color: #FFF;
     	}
     	.footer-logo a{
     		color: #FFF;
     	}
     </style>
     <style>
     footer {
       background-color: yellow;
     }
     
     @media only screen and (max-width: 600px) {
       footer {
         background-color: lightblue;
       }
     }
     </style>
     <div class="footer-area foomter" style="background-color: #138750">
     <div class="container">
     <div class="row">
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     <style>
         #connectcenter {
           background-color: #ffC82D;
           margin-top: -20px;
         }
         #connectcenter img {
          
           margin: 0px 16px 0px 0px;
           width: 32px !important;
         }
         #connectcenter li {
           font-size: 1.2em;
           
         }
     	   a#social{text-decoration: none;
     	  color: #444444;}
     
         .img-thumbnail{
           background-color: none;
     
         }
         
      </style>
     <div class="yellow darken-4 white-text foomter" id="connectcenter" style="border-top: solid 1px white;padding-left: 20px">
     <h3>Connect Centre</h3>
     <div class="row">
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>Toll Free Number: <b>6232</b>
     </div>
     <div class="col-md-4">
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>
     </div>
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>SMS Number: <b>+234809 955 5577</b>
     </div>
     </div>
     </div>
     <script src="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.js"></script>
     <script src="/static/js/vendor-all.min.js"></script>
     <script crossorigin="anonymous" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
     <script src="/static/js/pcoded.min.js"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js" type="text/javascript"></script>
     <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js" type="text/javascript"></script>
     <script src="/static/js/app.js" type="text/javascript"></script>
     <!-- Global site tag (gtag.js) - Google Analytics -->
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-X0FT1KY27K"></script>
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'G-X0FT1KY27K');
     
         </script>
     <!-- Global site tag (gtag.js) - Google Analytics -->
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-161734978-1"></script>
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'UA-161734978-1');
         </script>
     <script>
           function init() {
     var vidDefer = document.getElementsByTagName('iframe');
     for (var i=0; i<vidDefer.length; i++) {
     if(vidDefer[i].getAttribute('data-src')) {
     vidDefer[i].setAttribute('src',vidDefer[i].getAttribute('data-src'));
     } } }
     window.onload = init;
       </script>
     <script>
       $(document).ready(function(){
           $("#myModal").modal('show');
       });
     
     
     </script>
     </body>,
     <div class="loader-bg">
     <div class="loader-track">
     <div class="loader-fill"></div>
     </div>
     </div>,
     <div class="loader-track">
     <div class="loader-fill"></div>
     </div>,
     <div class="loader-fill"></div>,
     <style>
       .pcoded-header.header-green a:hover, .pcoded-header.header-green dropdown-toggle {
         color:#FFC82D;
     }
     </style>,
     <nav class="pcoded-navbar menupos-fixed menu-light">
     <div class="navbar-wrapper">
     <div class="navbar-content scroll-div">
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>
     </div>
     </div>
     </nav>,
     <div class="navbar-wrapper">
     <div class="navbar-content scroll-div">
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>
     </div>
     </div>,
     <div class="navbar-content scroll-div">
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>
     </div>,
     <ul class="nav pcoded-inner-navbar">
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>
     
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>
     </ul>,
     <li class="nav-item pcoded-menu-caption">
     <label>NAVIGATION</label>
     </li>,
     <label>NAVIGATION</label>,
     <li class="nav-item">
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>
     </li>,
     <a class="nav-link" href="/report/"> <span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Dashboard</span></a>,
     <span class="pcoded-micon"><i class="feather icon-home"></i></span>,
     <i class="feather icon-home"></i>,
     <span class="pcoded-mtext">Dashboard</span>,
     <li class="nav-item">
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>
     </li>,
     <a class="nav-link" href="/state/"><span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span><span class="pcoded-mtext">Epicurve</span></a>,
     <span class="pcoded-micon"><i class="fas fa-chart-bar"></i></span>,
     <i class="fas fa-chart-bar"></i>,
     <span class="pcoded-mtext">Epicurve</span>,
     <li class="nav-item">
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>
     </li>,
     <a class="nav-link" href="/progression/"><span class="pcoded-micon"><i class="feather icon-layout"></i></span><span class="pcoded-mtext">Progression</span></a>,
     <span class="pcoded-micon"><i class="feather icon-layout"></i></span>,
     <i class="feather icon-layout"></i>,
     <span class="pcoded-mtext">Progression</span>,
     <li class="nav-item">
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>
     </li>,
     <a class="nav-link" href="/faq/"><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">FAQs</span></a>,
     <span class="pcoded-micon"><i class="feather icon-users"></i></span>,
     <i class="feather icon-users"></i>,
     <span class="pcoded-mtext">FAQs</span>,
     <li class="nav-item">
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>
     </li>,
     <a class="nav-link" href="/nitpfaq/"><span class="pcoded-micon"><i class="fa fa-plane"></i></span><span class="pcoded-mtext">Travel Portal FAQs</span></a>,
     <span class="pcoded-micon"><i class="fa fa-plane"></i></span>,
     <i class="fa fa-plane"></i>,
     <span class="pcoded-mtext">Travel Portal FAQs</span>,
     <li class="nav-item">
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>
     </li>,
     <a class="nav-link" href="/advisory/"><span class="pcoded-micon"><i class="feather icon-gitlab"></i></span><span class="pcoded-mtext">Advisory</span></a>,
     <span class="pcoded-micon"><i class="feather icon-gitlab"></i></span>,
     <i class="feather icon-gitlab"></i>,
     <span class="pcoded-mtext">Advisory</span>,
     <li class="nav-item">
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>
     </li>,
     <a class="nav-link" href="/guideline/"><span class="pcoded-micon"><i class="fa fa-book"></i></span><span class="pcoded-mtext">Guidelines</span></a>,
     <span class="pcoded-micon"><i class="fa fa-book"></i></span>,
     <i class="fa fa-book"></i>,
     <span class="pcoded-mtext">Guidelines</span>,
     <li class="nav-item">
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>
     </li>,
     <a class="nav-link" href="/samplesites/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Sample Collection Sites</span></a>,
     <span class="pcoded-micon"><i class="feather icon-feather"></i></span>,
     <i class="feather icon-feather"></i>,
     <span class="pcoded-mtext">Sample Collection Sites</span>,
     <li class="nav-item">
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>
     </li>,
     <a class="nav-link" href="/resource/"><span class="pcoded-micon"><i class="feather icon-feather"></i></span><span class="pcoded-mtext">Resources</span></a>,
     <span class="pcoded-micon"><i class="feather icon-feather"></i></span>,
     <i class="feather icon-feather"></i>,
     <span class="pcoded-mtext">Resources</span>,
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>
     </li>,
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="fa fa-flask"></i></span><span class="pcoded-mtext">Laboratories</span></a>,
     <span class="pcoded-micon"><i class="fa fa-flask"></i></span>,
     <i class="fa fa-flask"></i>,
     <span class="pcoded-mtext">Laboratories</span>,
     <ul class="pcoded-submenu">
     <li><a href="/laboratory/">Government Laboratories</a></li>
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>
     <li><a href="/corporatelabs/">Corporate Labs</a></li>
     </ul>,
     <li><a href="/laboratory/">Government Laboratories</a></li>,
     <a href="/laboratory/">Government Laboratories</a>,
     <li><a href="/privatelabs/">Fee-Paying Private Laboratories</a></li>,
     <a href="/privatelabs/">Fee-Paying Private Laboratories</a>,
     <li><a href="/corporatelabs/">Corporate Labs</a></li>,
     <a href="/corporatelabs/">Corporate Labs</a>,
     <li class="nav-item pcoded-hasmenu">
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>
     </li>,
     <a class="nav-link" href="#!"><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Nigeria Data</span></a>,
     <span class="pcoded-micon"><i class="feather icon-home"></i></span>,
     <i class="feather icon-home"></i>,
     <span class="pcoded-mtext">Nigeria Data</span>,
     <ul class="pcoded-submenu">
     <li><a href="/gis/">Web View</a></li>
     <li><a href="/gism/">Mobile View</a></li>
     </ul>,
     <li><a href="/gis/">Web View</a></li>,
     <a href="/gis/">Web View</a>,
     <li><a href="/gism/">Mobile View</a></li>,
     <a href="/gism/">Mobile View</a>,
     <li class="nav-item">
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>
     </li>,
     <a class="nav-link" href="/globals/"><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Global</span></a>,
     <span class="pcoded-micon"><i class="feather icon-layers"></i></span>,
     <i class="feather icon-layers"></i>,
     <span class="pcoded-mtext">Global</span>,
     <div class="card text-center">
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>
     </div>,
     <div class="card-block">
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>
     <i class="fa fa-users-o f-40"></i>
     <h6 class="mt-3">Self Assessment</h6>
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>
     </div>,
     <button aria-hidden="true" class="close" data-dismiss="alert" type="button">×</button>,
     <i class="fa fa-users-o f-40"></i>,
     <h6 class="mt-3">Self Assessment</h6>,
     <p>
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>
     </p>,
     <a class="btn btn-success btn-sm text-white m-0" href="https://selfassessment.ncdc.gov.ng" target="_blank">Get Your COVID-19 Risk Assessment</a>,
     <header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed header-green">
     <div class="m-header">
     <a class="mobile-menu" href="#!" id="mobile-collapse"><span></span></a>
     <a class="b-brand" href="#!">
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>
     </a>
     <a class="mob-toggler" href="#!">
     <i class="feather icon-more-vertical"></i>
     </a>
     </div>
     <div class="collapse navbar-collapse">
     <ul class="navbar-nav mr-auto">
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>
     </ul>
     <ul class="navbar-nav ml-auto">
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>
     <li>
     </li>
     </ul>
     </div>
     </header>,
     <div class="m-header">
     <a class="mobile-menu" href="#!" id="mobile-collapse"><span></span></a>
     <a class="b-brand" href="#!">
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>
     </a>
     <a class="mob-toggler" href="#!">
     <i class="feather icon-more-vertical"></i>
     </a>
     </div>,
     <a class="mobile-menu" href="#!" id="mobile-collapse"><span></span></a>,
     <span></span>,
     <a class="b-brand" href="#!">
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>
     </a>,
     <img alt="" class="logo" height="45" src="/static/ncdc_img/ncdc_logo_black_text.png" width="120"/>,
     <a class="mob-toggler" href="#!">
     <i class="feather icon-more-vertical"></i>
     </a>,
     <i class="feather icon-more-vertical"></i>,
     <div class="collapse navbar-collapse">
     <ul class="navbar-nav mr-auto">
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>
     </ul>
     <ul class="navbar-nav ml-auto">
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>
     <li>
     </li>
     </ul>
     </div>,
     <ul class="navbar-nav mr-auto">
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>
     </ul>,
     <li class="nav-item">
     <!-- <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>-->
     </li>,
     <li class="nav-item">
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>
     </li>,
     <a class="full-screen" href="#!" onclick="javascript:toggleFullScreen()"><i class="feather icon-maximize"></i></a>,
     <i class="feather icon-maximize"></i>,
     <ul class="navbar-nav ml-auto">
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>
     <li>
     </li>
     </ul>,
     <li>
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>
     </div>,
     <a href="https://ngcovid19resourcetracker.info" target="_blank"><i class="fa fa-blog"></i> <span>PTF Resource</span></a>,
     <i class="fa fa-blog"></i>,
     <span>PTF Resource</span>,
     <li>
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>
     </div>,
     <a href="/validation/"><i class="fa fa-check"></i> <span>Check Test Results</span></a>,
     <i class="fa fa-check"></i>,
     <span>Check Test Results</span>,
     <li>
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>
     </div>,
     <a href="/contact/"><i class="fa fa-phone"></i> <span>State Emergency Contacts</span></a>,
     <i class="fa fa-phone"></i>,
     <span>State Emergency Contacts</span>,
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>
     </div>,
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><i class="fa fa-newspaper"></i> <span>Situation Reports</span></a>,
     <i class="fa fa-newspaper"></i>,
     <span>Situation Reports</span>,
     <li>
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>
     </div>,
     <a href="https://covid19blog.ncdc.gov.ng/" target="_blank"><i class="fa fa-blog"></i> <span>COVID19blog</span></a>,
     <i class="fa fa-blog"></i>,
     <span>COVID19blog</span>,
     <li>
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>
     </li>,
     <div class="dropdown">
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>
     </div>,
     <a href="https://ncdc.gov.ng/" target="_blank"><i class="fa fa-rocket"></i>
     <span>NCDC</span></a>,
     <i class="fa fa-rocket"></i>,
     <span>NCDC</span>,
     <li>
     </li>,
     <div class="pcoded-main-container">
     <div class="pcoded-content">
     <div class="page-header">
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row card-header">
     <h4>Updates</h4>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="pcoded-content">
     <div class="page-header">
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row card-header">
     <h4>Updates</h4>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="page-header">
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row card-header">
     <h4>Updates</h4>
     </div>
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>
     </div>,
     <div class="page-block">
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="row">
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>
     </div>,
     <div class="col-md-12 col-xl-9">
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>
     </div>,
     <div class="card bg-c-white order-card">
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>
     </div>,
     <div class="card-body">
     <h1 class="text-black">COVID-19 NIGERIA </h1>
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>
     </div>,
     <h1 class="text-black">COVID-19 NIGERIA </h1>,
     <h6><p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>
     </h6>,
     <p class="m-b-0"><span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span></p>,
     <span class="float-right">
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>
     </span>,
     <script>
     
                                                 var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                                                 var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
     
                                                 var d = new Date();
                                               var day = days[d.getDay()];
                                               var hr = d.getHours();
                                                 var min = d.getMinutes();
                                             if (min < 10) {
                                                 min = "0" + min;
                                                 }
                                                 var ampm = "am";
                                                 if( hr > 12 ) {
                                                   hr -= 12;
                                                   ampm = "pm";
                                                 }
                                         var date = d.getDate();
                                         var month = months[d.getMonth()];
                                         var year = d.getFullYear();
                                         var x = document.getElementById("time");
                                         var fullDate = day + " " + hr + ":" + min + " "+ ampm + " " + date + " " + month + " " + year;
                                         document.write(fullDate);
                                             </script>,
     <style>.newcol {
                                 background: rgba(106, 98, 36, 0.64);
                             }
                             </style>,
     <div class="col-md-12 col-xl-3">
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>
     </div>,
     <div class="card newcol order-card">
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>
     </div>,
     <div class="card-body">
     <h6 class="text-white">Samples Tested</h6>
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>
     </div>,
     <h6 class="text-white">Samples Tested</h6>,
     <h2 class="text-right text-white">
     <i class="fa fa-viruses float-left"></i><span>5,279,608</span></h2>,
     <i class="fa fa-viruses float-left"></i>,
     <span>5,279,608</span>,
     <div class="row">
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>
     </div>,
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>
     </div>,
     <div class="card bg-c-blue order-card">
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>
     </div>,
     <div class="card-body">
     <h6 class="text-white">Confirmed Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>
     </div>,
     <h6 class="text-white">Confirmed Cases</h6>,
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>257,637</span></h2>,
     <i class="fa fa-viruses float-left"></i>,
     <span>257,637</span>,
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>
     </div>,
     <div class="card bg-c-yellow order-card">
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>
     </div>,
     <div class="card-body">
     <h6 class="text-white">Active Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>
     </div>,
     <h6 class="text-white">Active Cases</h6>,
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>4,206</span></h2>,
     <i class="fa fa-viruses float-left"></i>,
     <span>4,206</span>,
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>
     </div>,
     <div class="card bg-c-green order-card">
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>
     </div>,
     <div class="card-body">
     <h6 class="text-white">Discharged Cases</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>
     </div>,
     <h6 class="text-white">Discharged Cases</h6>,
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>250,287</span></h2>,
     <i class="fa fa-viruses float-left"></i>,
     <span>250,287</span>,
     <div class="col-xs-3 col-md-3 col-xl-3">
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>
     </div>,
     <div class="card bg-c-red order-card">
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>
     </div>,
     <div class="card-body">
     <h6 class="text-white">Death</h6>
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>
     </div>,
     <h6 class="text-white">Death</h6>,
     <h2 class="text-right text-white"><i class="fa fa-viruses float-left"></i><span>3,144</span></h2>,
     <i class="fa fa-viruses float-left"></i>,
     <span>3,144</span>,
     <style>
                         #custom1 {
                             border-collapse: collapse;
                             width: 100%;
                             /*font-family: Segoe;*/
                         }
     
                         #custom1 td, #custom1 th {
                             border: 1px solid #ddd;
                             padding: 8px;
                         }
     
                         #custom1 tr:nth-child(even) {
                             background-color: #f2f2f2;
                         }
     
                         #custom1 tr:hover {
                             background-color: #ddd;
                         }
     
                         #custom1 th {
                             padding-top: 12px;
                             padding-bottom: 12px;
                             text-align: left;
                             background-color: #138750;
                             color: white;
                         }
                     </style>,
     <div class="row">
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="col-xl-7">
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>
     </div>,
     <div class="card">
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>
     </div>,
     <div class="card-header">
     <h4 class="card-title">Confirmed Cases by State</h4>
     </div>,
     <h4 class="card-title">Confirmed Cases by State</h4>,
     <div class="card-body">
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>
     </div>,
     <div class="table-responsive">
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>
     </div>,
     <table id="custom1">
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>
     </table>,
     <thead>
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>
     </thead>,
     <tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>,
     <th>States Affected</th>,
     <th>No. of Cases (Lab Confirmed)</th>,
     <th>No. of Cases (on admission)</th>,
     <th>No. Discharged</th>,
     <th>No. of Deaths</th>,
     <tbody>
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>
     </tbody>,
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>,
     <td>
                                                     Lagos
                                                 </td>,
     <td>100,641
                                                 </td>,
     <td>1,810
                                                 </td>,
     <td>98,062
                                                 </td>,
     <td>769
                                                 </td>,
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>,
     <td>
                                                     FCT
                                                 </td>,
     <td>28,763
                                                 </td>,
     <td>63
                                                 </td>,
     <td>28,451
                                                 </td>,
     <td>249
                                                 </td>,
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>,
     <td>
                                                     Rivers
                                                 </td>,
     <td>16,826
                                                 </td>,
     <td>127
                                                 </td>,
     <td>16,545
                                                 </td>,
     <td>154
                                                 </td>,
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>,
     <td>
                                                     Kaduna
                                                 </td>,
     <td>11,314
                                                 </td>,
     <td>7
                                                 </td>,
     <td>11,218
                                                 </td>,
     <td>89
                                                 </td>,
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>,
     <td>
                                                     Plateau
                                                 </td>,
     <td>10,258
                                                 </td>,
     <td>2
                                                 </td>,
     <td>10,181
                                                 </td>,
     <td>75
                                                 </td>,
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>,
     <td>
                                                     Oyo
                                                 </td>,
     <td>10,232
                                                 </td>,
     <td>1
                                                 </td>,
     <td>10,029
                                                 </td>,
     <td>202
                                                 </td>,
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>,
     <td>
                                                     Edo
                                                 </td>,
     <td>7,707
                                                 </td>,
     <td>11
                                                 </td>,
     <td>7,375
                                                 </td>,
     <td>321
                                                 </td>,
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>,
     <td>
                                                     Ogun
                                                 </td>,
     <td>5,810
                                                 </td>,
     <td>11
                                                 </td>,
     <td>5,717
                                                 </td>,
     <td>82
                                                 </td>,
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>,
     <td>
                                                     Delta
                                                 </td>,
     <td>5,413
                                                 </td>,
     <td>132
                                                 </td>,
     <td>5,170
                                                 </td>,
     <td>111
                                                 </td>,
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>,
     <td>
                                                     Ondo
                                                 </td>,
     <td>5,173
                                                 </td>,
     <td>315
                                                 </td>,
     <td>4,749
                                                 </td>,
     <td>109
                                                 </td>,
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>,
     <td>
                                                     Kano
                                                 </td>,
     <td>5,087
                                                 </td>,
     <td>49
                                                 </td>,
     <td>4,911
                                                 </td>,
     <td>127
                                                 </td>,
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>,
     <td>
                                                     Akwa Ibom
                                                 </td>,
     <td>4,659
                                                 </td>,
     <td>29
                                                 </td>,
     <td>4,586
                                                 </td>,
     <td>44
                                                 </td>,
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>,
     <td>
                                                     Kwara
                                                 </td>,
     <td>4,640
                                                 </td>,
     <td>401
                                                 </td>,
     <td>4,175
                                                 </td>,
     <td>64
                                                 </td>,
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>,
     <td>
                                                     Osun
                                                 </td>,
     <td>3,311
                                                 </td>,
     <td>36
                                                 </td>,
     <td>3,183
                                                 </td>,
     <td>92
                                                 </td>,
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>,
     <td>
                                                     Gombe
                                                 </td>,
     <td>3,307
                                                 </td>,
     <td>83
                                                 </td>,
     <td>3,158
                                                 </td>,
     <td>66
                                                 </td>,
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>,
     <td>
                                                     Enugu
                                                 </td>,
     <td>2,952
                                                 </td>,
     <td>13
                                                 </td>,
     <td>2,910
                                                 </td>,
     <td>29
                                                 </td>,
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>,
     <td>
                                                     Anambra
                                                 </td>,
     <td>2,825
                                                 </td>,
     <td>46
                                                 </td>,
     <td>2,760
                                                 </td>,
     <td>19
                                                 </td>,
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>,
     <td>
                                                     Nasarawa
                                                 </td>,
     <td>2,738
                                                 </td>,
     <td>354
                                                 </td>,
     <td>2,345
                                                 </td>,
     <td>39
                                                 </td>,
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>,
     <td>
                                                     Imo
                                                 </td>,
     <td>2,648
                                                 </td>,
     <td>8
                                                 </td>,
     <td>2,582
                                                 </td>,
     <td>58
                                                 </td>,
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>,
     <td>
                                                     Katsina
                                                 </td>,
     <td>2,418
                                                 </td>,
     <td>0
                                                 </td>,
     <td>2,381
                                                 </td>,
     <td>37
                                                 </td>,
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>,
     <td>
                                                     Abia
                                                 </td>,
     <td>2,177
                                                 </td>,
     <td>1
                                                 </td>,
     <td>2,142
                                                 </td>,
     <td>34
                                                 </td>,
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>,
     <td>
                                                     Benue
                                                 </td>,
     <td>2,129
                                                 </td>,
     <td>340
                                                 </td>,
     <td>1,764
                                                 </td>,
     <td>25
                                                 </td>,
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>,
     <td>
                                                     Ebonyi
                                                 </td>,
     <td>2,064
                                                 </td>,
     <td>28
                                                 </td>,
     <td>2,004
                                                 </td>,
     <td>32
                                                 </td>,
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <td>
                                                     Ekiti
                                                 </td>,
     <td>2,006
                                                 </td>,
     <td>52
                                                 </td>,
     <td>1,926
                                                 </td>,
     <td>28
                                                 </td>,
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>,
     <td>
                                                     Bauchi
                                                 </td>,
     <td>1,967
                                                 </td>,
     <td>1
                                                 </td>,
     <td>1,942
                                                 </td>,
     <td>24
                                                 </td>,
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>,
     <td>
                                                     Borno
                                                 </td>,
     <td>1,629
                                                 </td>,
     <td>5
                                                 </td>,
     <td>1,580
                                                 </td>,
     <td>44
                                                 </td>,
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>,
     <td>
                                                     Taraba
                                                 </td>,
     <td>1,473
                                                 </td>,
     <td>62
                                                 </td>,
     <td>1,377
                                                 </td>,
     <td>34
                                                 </td>,
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <td>
                                                     Bayelsa
                                                 </td>,
     <td>1,321
                                                 </td>,
     <td>1
                                                 </td>,
     <td>1,292
                                                 </td>,
     <td>28
                                                 </td>,
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>,
     <td>
                                                     Adamawa
                                                 </td>,
     <td>1,203
                                                 </td>,
     <td>68
                                                 </td>,
     <td>1,103
                                                 </td>,
     <td>32
                                                 </td>,
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>,
     <td>
                                                     Niger
                                                 </td>,
     <td>1,148
                                                 </td>,
     <td>130
                                                 </td>,
     <td>998
                                                 </td>,
     <td>20
                                                 </td>,
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>,
     <td>
                                                     Cross River
                                                 </td>,
     <td>842
                                                 </td>,
     <td>8
                                                 </td>,
     <td>809
                                                 </td>,
     <td>25
                                                 </td>,
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <td>
                                                     Sokoto
                                                 </td>,
     <td>818
                                                 </td>,
     <td>0
                                                 </td>,
     <td>790
                                                 </td>,
     <td>28
                                                 </td>,
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>,
     <td>
                                                     Jigawa
                                                 </td>,
     <td>669
                                                 </td>,
     <td>2
                                                 </td>,
     <td>649
                                                 </td>,
     <td>18
                                                 </td>,
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>,
     <td>
                                                     Yobe
                                                 </td>,
     <td>609
                                                 </td>,
     <td>0
                                                 </td>,
     <td>600
                                                 </td>,
     <td>9
                                                 </td>,
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>,
     <td>
                                                     Kebbi
                                                 </td>,
     <td>480
                                                 </td>,
     <td>10
                                                 </td>,
     <td>454
                                                 </td>,
     <td>16
                                                 </td>,
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>,
     <td>
                                                     Zamfara
                                                 </td>,
     <td>375
                                                 </td>,
     <td>0
                                                 </td>,
     <td>366
                                                 </td>,
     <td>9
                                                 </td>,
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>,
     <td>
                                                     Kogi
                                                 </td>,
     <td>5
                                                 </td>,
     <td>0
                                                 </td>,
     <td>3
                                                 </td>,
     <td>2
                                                 </td>,
     <div class="col-xl-5">
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>
     </div>,
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>
     </div>,
     <div class="card-header">
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>
     </div>,
     <div class="card-box">
     <!--  <a href="https://nitp.ncdc.gov.ng/splash-screen"><video width="400" height="auto" controls><source src="https://covid19.ncdc.gov.ng/media/nitp.mp4" type="video/mp4"></video></a>
                                     <br>-->
     <h4 class="card-title">Highlights</h4>
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>
     </div>,
     <h4 class="card-title">Highlights</h4>,
     <ul style="text-align: justify">
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>
     </ul>,
     <li>From 30th June to 1st July 2022, 347 new confirmed cases were recorded in Nigeria</li>,
     <li>Till date, 257637 cases have been confirmed, 250287 cases have been discharged and 3,144 deaths have been recorded in 36 states and the Federal Capital Territory</li>,
     <li>The 347 new cases are reported from 8 States- Lagos (265), Imo (47), Rivers (15), Edo (11), FCT (4), Akwa Ibom (2), Plateau (2), and Bayelsa (1)</li>,
     <li>A multi-sectoral national emergency operations centre (EOC), activated at Level 2, continues to coordinate the national response activities</li>,
     <a href="https://ncdc.gov.ng/diseases/sitreps/?cat=14&amp;name=An%20update%20of%20COVID-19%20outbreak%20in%20Nigeria" target="_blank"><b>Click here to read more</b></a>,
     <b>Click here to read more</b>,
     <div class="card feed-card">
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>
     </div>,
     <div class="card-header">
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>
     </div>,
     <div class="card-box">
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>
     </div>,
     <a class="twitter-timeline" data-chrome="nofooter noborders transparent" data-height="800" data-lang="en" data-theme="light" href="https://twitter.com/NCDCgov?ref_src=twsrc%5Etfw">Tweets by NCDCgov</a>,
     <script async="" charset="utf-8" src="https://platform.twitter.com/widgets.js"></script>,
     <div class="row card-header">
     <h4>Updates</h4>
     </div>,
     <h4>Updates</h4>,
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>
     <span class="time">April 18, 2022</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/F5_-_IMPLEMENTATION_GUIDELINES_Ako.pdf" target="_blank">IMPLEMENTATION GUIDELINES FOR EASING COVID-19 RESTRICTIONS </a>,
     <span class="time">April 18, 2022</span>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>
     <span class="time">Dec. 3, 2021</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf" target="_blank">International Travel Protocol into Nigeria - 2nd April, 2022 </a>,
     <span class="time">Dec. 3, 2021</span>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/PRIVATE_LABS_TRAVEL_Data.pdf" target="_blank">Private Labs Travel Data Report </a>,
     <span class="time">Nov. 11, 2021</span>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121_Ox23ng9.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a>,
     <span class="time">Nov. 11, 2021</span>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>
     <span class="time">Nov. 11, 2021</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/COVID19_private_sector__labs_MLSCN_updated_081121.docx" target="_blank">A revised version of the private sector guidance for COVID labs </a>,
     <span class="time">Nov. 11, 2021</span>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>
     </div>,
     <div class="card" style="height: 100px;">
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>
     </div>,
     <div class="timeline-content">
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>
     <span class="time">Nov. 2, 2021</span>
     </div>,
     <span style="display: block">
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a></span>,
     <i aria-hidden="true" class="fa fa-file-pdf" style="color:red"></i>,
     <a class="name" href="/media/files/NITP_STATEMENT_2112021_Ako.pdf" target="_blank">STATEMENT ON THE NITP PORTAL UPGRADE </a>,
     <span class="time">Nov. 2, 2021</span>,
     <div class="row" style="margin-left: 10px">
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>
     </div>,
     <a href="/archive/" target="_blank"><b>Click here to access archive</b></a>,
     <b>Click here to access archive</b>,
     <div class="row">
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>,
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>,
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>,
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/G-wB_IANUzw" frameborder="0" height="315" src="" width="100%"></iframe>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>
     </div>,
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>
     </div>,
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>
     </div>,
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/tOM68QCA5sk" frameborder="0" height="315" src="" width="100%"></iframe>,
     <div class="col-md-4 col-sm-4 col-lg-4">
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="card">
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="card-body">
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>
     <!-- The Modal -->
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>
     </div>,
     <iframe allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen="" data-src="https://www.youtube.com/embed/PToko-KysHs" frameborder="0" height="315" src="" width="100%"></iframe>,
     <div class="modal" id="myModal">
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>
     </div>,
     <div class="modal-dialog">
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>
     </div>,
     <div class="modal-content" id="travel">
     <!-- Modal Header -->
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>
     <!-- Modal body -->
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>
     <!-- Modal footer -->
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>
     </div>,
     <div class="modal-header">
     <h4 class="modal-title text-center">On International Travel</h4>
     <button class="close" data-dismiss="modal" type="button">×</button>
     </div>,
     <h4 class="modal-title text-center">On International Travel</h4>,
     <button class="close" data-dismiss="modal" type="button">×</button>,
     <div class="modal-body">
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>
     </div>,
     <a href="https://nitp.ncdc.gov.ng/splash-screen"> <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img></a>,
     <img class="img-fluid" src="https://covid19.ncdc.gov.ng/media/files/Artboard-1NITP-Live-prenicafe.jpg"> </img>,
     <div class="modal-footer">
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a> <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>
     <!--  <a href="https://covid19.ncdc.gov.ng/media/files/PRESIDENTIAL%20STEERING%20COMMITTEE%20ON%20COVID-19%20corrected.pdf" class="btn btn-danger text-white">For travellers from Brazil and Turkey</a>
                 https://covid19.ncdc.gov.ng/media/files/RELEASE_OF_REVISED_INTERNATIONAL_TRAVEL_PROTOCOL_INTO_NIGERIA_PDF.pdf
               -->
     <!--  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>  -->
     </div>,
     <a class="btn btn-dark text-white" href="https://covid19.ncdc.gov.ng/nitpfaq/">Travel Portal FAQs</a>,
     <a class="btn btn-primary text-white" href="https://covid19.ncdc.gov.ng/media/files/Revised_Travel_protocol_revised_2nd_April_2022.pdf">Download Travel Protocol</a>,
     <style>
     	.footer-content{
     	
     		padding: 30px;
     		
     	}
     	.footer-content a{
     		color: white;
     	}
     	.social{
     		color: #FFF;
     	}
     	.footer-logo a{
     		color: #FFF;
     	}
     </style>,
     <style>
     footer {
       background-color: yellow;
     }
     
     @media only screen and (max-width: 600px) {
       footer {
         background-color: lightblue;
       }
     }
     </style>,
     <div class="footer-area foomter" style="background-color: #138750">
     <div class="container">
     <div class="row">
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="container">
     <div class="row">
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>
     </div>
     </div>,
     <div class="row">
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>
     <!-- end single footer -->
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>
     </div>,
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>
     </div>,
     <div class="footer-content text-white">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>
     </div>,
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>
     </div>,
     <div class="footer-logo">
     <h2 class="text-white">Contact</h2>
     </div>,
     <h2 class="text-white">Contact</h2>,
     <p>Plot 801, Ebitu Ukiwe Street, Jabi, Abuja, Nigeria<br/>
                       6232 (Toll-Free Call Centre)<br/>
                       info@ncdc.gov.ng</p>,
     <br/>,
     <br/>,
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>
     </div>,
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>
     </div>,
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>
     <hr/>
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>
     </div>,
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Social Media</h2>
     </div>,
     <h2 class="text-white"><span></span>Social Media</h2>,
     <span></span>,
     <div class="text-white social">
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>
     </div>,
     <a href="https://facebook.com/NCDCgov" style="color: #FFF;" target="_blank"><i class="la la-facebook"></i> @NCDCGov</a>,
     <i class="la la-facebook"></i>,
     <div class="text-white social">
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>
     </div>,
     <a class="text-white" href="https://twitter.com/NCDCgov" target="_blank"><i class="la la-twitter"></i> @NCDCGov</a>,
     <i class="la la-twitter"></i>,
     <div class="text-white social">
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>
     </div>,
     <a class="text-white" href="https://www.youtube.com/channel/UC1PmRDsjQC5ovpmEBmNhuGg" target="_blank"><i class="la la-youtube"></i> NCDC</a>,
     <i class="la la-youtube"></i>,
     <div class="text-white social">
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>
     </div>,
     <a class="text-white" href="https://instagram.com/ncdcgov" target="_blank"><i class="la la-instagram"></i> NCDCgov</a>,
     <i class="la la-instagram"></i>,
     <div class="text-white social">
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>
     </div>,
     <a class="text-white" href="https://t.me/NCDCgov" target="_blank"><i class="fa fa-envelope"></i> t.me/NCDCgov (Telegram)</a>,
     <i class="fa fa-envelope"></i>,
     <hr/>,
     <div class="text-white social" style="font-size: 7px !important;">
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>
     </div>,
     <p style="font-size: 10px !important;">Supported by Georgetown University - CGHPI</p>,
     <div class="col-md-4 col-sm-4 col-xs-12">
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>
     </div>,
     <div class="footer-content">
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>
     </div>,
     <div class="footer-head">
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>
     </div>,
     <div class="footer-logo">
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>
     </div>,
     <h2 class="text-white"><span></span>Mandate of NCDC</h2>,
     <span></span>,
     <p class="text-white">
                       The Nigeria Centre for Disease Control (NCDC) was established in the year 2011 in response to the challenges of public health emergencies and to enhance Nigeria’s preparedness and response to epidemics through prevention, detection and control of communicable diseases.  
     
                     </p>,
     <style>
         #connectcenter {
           background-color: #ffC82D;
           margin-top: -20px;
         }
         #connectcenter img {
          
           margin: 0px 16px 0px 0px;
           width: 32px !important;
         }
         #connectcenter li {
           font-size: 1.2em;
           
         }
     	   a#social{text-decoration: none;
     	  color: #444444;}
     
         .img-thumbnail{
           background-color: none;
     
         }
         
      </style>,
     <div class="yellow darken-4 white-text foomter" id="connectcenter" style="border-top: solid 1px white;padding-left: 20px">
     <h3>Connect Centre</h3>
     <div class="row">
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>Toll Free Number: <b>6232</b>
     </div>
     <div class="col-md-4">
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>
     </div>
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>SMS Number: <b>+234809 955 5577</b>
     </div>
     </div>
     </div>,
     <h3>Connect Centre</h3>,
     <div class="row">
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>Toll Free Number: <b>6232</b>
     </div>
     <div class="col-md-4">
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>
     </div>
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>SMS Number: <b>+234809 955 5577</b>
     </div>
     </div>,
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>Toll Free Number: <b>6232</b>
     </div>,
     <img class="img img-thumbnail img-responsive" src="/static/img/public-phone1.png" style="width: 64px"/>,
     <b>6232</b>,
     <div class="col-md-4">
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>
     </div>,
     <a href="https://api.whatsapp.com/send?phone=+2347087110839" id="social"><img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>Whatsapp: <b>+234708 711 0839</b></a>,
     <img class="img img-thumbnail img-responsive" src="/static/images/social/whatsapp.png" style="width: 64px"/>,
     <b>+234708 711 0839</b>,
     <div class="col-md-4">
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>SMS Number: <b>+234809 955 5577</b>
     </div>,
     <img class="img img-thumbnail img-responsive" src="/static/images/social/public-phone.png" style="width: 64px"/>,
     <b>+234809 955 5577</b>,
     <script src="https://ncdcgloepid.blob.core.windows.net/ncdc-gloepid/gloepid-embed.min.js"></script>,
     <script src="/static/js/vendor-all.min.js"></script>,
     <script crossorigin="anonymous" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>,
     <script src="/static/js/pcoded.min.js"></script>,
     <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js" type="text/javascript"></script>,
     <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js" type="text/javascript"></script>,
     <script src="/static/js/app.js" type="text/javascript"></script>,
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=G-X0FT1KY27K"></script>,
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'G-X0FT1KY27K');
     
         </script>,
     <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-161734978-1"></script>,
     <script>
         window.dataLayer = window.dataLayer || [];
         function gtag(){dataLayer.push(arguments);}
         gtag('js', new Date());
     
         gtag('config', 'UA-161734978-1');
         </script>,
     <script>
           function init() {
     var vidDefer = document.getElementsByTagName('iframe');
     for (var i=0; i<vidDefer.length; i++) {
     if(vidDefer[i].getAttribute('data-src')) {
     vidDefer[i].setAttribute('src',vidDefer[i].getAttribute('data-src'));
     } } }
     window.onload = init;
       </script>,
     <script>
       $(document).ready(function(){
           $("#myModal").modal('show');
       });
     
     
     </script>]




```python
table = covid.find('table')
rows = table.find_all("tr")
```


```python
table
```




    <table id="custom1">
    <thead>
    <tr>
    <th>States Affected</th>
    <th>No. of Cases (Lab Confirmed)</th>
    <th>No. of Cases (on admission)</th>
    <th>No. Discharged</th>
    <th>No. of Deaths</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td>
                                                    Lagos
                                                </td>
    <td>100,641
                                                </td>
    <td>1,810
                                                </td>
    <td>98,062
                                                </td>
    <td>769
                                                </td>
    </tr>
    <tr>
    <td>
                                                    FCT
                                                </td>
    <td>28,763
                                                </td>
    <td>63
                                                </td>
    <td>28,451
                                                </td>
    <td>249
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Rivers
                                                </td>
    <td>16,826
                                                </td>
    <td>127
                                                </td>
    <td>16,545
                                                </td>
    <td>154
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Kaduna
                                                </td>
    <td>11,314
                                                </td>
    <td>7
                                                </td>
    <td>11,218
                                                </td>
    <td>89
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Plateau
                                                </td>
    <td>10,258
                                                </td>
    <td>2
                                                </td>
    <td>10,181
                                                </td>
    <td>75
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Oyo
                                                </td>
    <td>10,232
                                                </td>
    <td>1
                                                </td>
    <td>10,029
                                                </td>
    <td>202
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Edo
                                                </td>
    <td>7,707
                                                </td>
    <td>11
                                                </td>
    <td>7,375
                                                </td>
    <td>321
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Ogun
                                                </td>
    <td>5,810
                                                </td>
    <td>11
                                                </td>
    <td>5,717
                                                </td>
    <td>82
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Delta
                                                </td>
    <td>5,413
                                                </td>
    <td>132
                                                </td>
    <td>5,170
                                                </td>
    <td>111
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Ondo
                                                </td>
    <td>5,173
                                                </td>
    <td>315
                                                </td>
    <td>4,749
                                                </td>
    <td>109
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Kano
                                                </td>
    <td>5,087
                                                </td>
    <td>49
                                                </td>
    <td>4,911
                                                </td>
    <td>127
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Akwa Ibom
                                                </td>
    <td>4,659
                                                </td>
    <td>29
                                                </td>
    <td>4,586
                                                </td>
    <td>44
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Kwara
                                                </td>
    <td>4,640
                                                </td>
    <td>401
                                                </td>
    <td>4,175
                                                </td>
    <td>64
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Osun
                                                </td>
    <td>3,311
                                                </td>
    <td>36
                                                </td>
    <td>3,183
                                                </td>
    <td>92
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Gombe
                                                </td>
    <td>3,307
                                                </td>
    <td>83
                                                </td>
    <td>3,158
                                                </td>
    <td>66
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Enugu
                                                </td>
    <td>2,952
                                                </td>
    <td>13
                                                </td>
    <td>2,910
                                                </td>
    <td>29
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Anambra
                                                </td>
    <td>2,825
                                                </td>
    <td>46
                                                </td>
    <td>2,760
                                                </td>
    <td>19
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Nasarawa
                                                </td>
    <td>2,738
                                                </td>
    <td>354
                                                </td>
    <td>2,345
                                                </td>
    <td>39
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Imo
                                                </td>
    <td>2,648
                                                </td>
    <td>8
                                                </td>
    <td>2,582
                                                </td>
    <td>58
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Katsina
                                                </td>
    <td>2,418
                                                </td>
    <td>0
                                                </td>
    <td>2,381
                                                </td>
    <td>37
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Abia
                                                </td>
    <td>2,177
                                                </td>
    <td>1
                                                </td>
    <td>2,142
                                                </td>
    <td>34
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Benue
                                                </td>
    <td>2,129
                                                </td>
    <td>340
                                                </td>
    <td>1,764
                                                </td>
    <td>25
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Ebonyi
                                                </td>
    <td>2,064
                                                </td>
    <td>28
                                                </td>
    <td>2,004
                                                </td>
    <td>32
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Ekiti
                                                </td>
    <td>2,006
                                                </td>
    <td>52
                                                </td>
    <td>1,926
                                                </td>
    <td>28
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Bauchi
                                                </td>
    <td>1,967
                                                </td>
    <td>1
                                                </td>
    <td>1,942
                                                </td>
    <td>24
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Borno
                                                </td>
    <td>1,629
                                                </td>
    <td>5
                                                </td>
    <td>1,580
                                                </td>
    <td>44
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Taraba
                                                </td>
    <td>1,473
                                                </td>
    <td>62
                                                </td>
    <td>1,377
                                                </td>
    <td>34
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Bayelsa
                                                </td>
    <td>1,321
                                                </td>
    <td>1
                                                </td>
    <td>1,292
                                                </td>
    <td>28
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Adamawa
                                                </td>
    <td>1,203
                                                </td>
    <td>68
                                                </td>
    <td>1,103
                                                </td>
    <td>32
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Niger
                                                </td>
    <td>1,148
                                                </td>
    <td>130
                                                </td>
    <td>998
                                                </td>
    <td>20
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Cross River
                                                </td>
    <td>842
                                                </td>
    <td>8
                                                </td>
    <td>809
                                                </td>
    <td>25
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Sokoto
                                                </td>
    <td>818
                                                </td>
    <td>0
                                                </td>
    <td>790
                                                </td>
    <td>28
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Jigawa
                                                </td>
    <td>669
                                                </td>
    <td>2
                                                </td>
    <td>649
                                                </td>
    <td>18
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Yobe
                                                </td>
    <td>609
                                                </td>
    <td>0
                                                </td>
    <td>600
                                                </td>
    <td>9
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Kebbi
                                                </td>
    <td>480
                                                </td>
    <td>10
                                                </td>
    <td>454
                                                </td>
    <td>16
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Zamfara
                                                </td>
    <td>375
                                                </td>
    <td>0
                                                </td>
    <td>366
                                                </td>
    <td>9
                                                </td>
    </tr>
    <tr>
    <td>
                                                    Kogi
                                                </td>
    <td>5
                                                </td>
    <td>0
                                                </td>
    <td>3
                                                </td>
    <td>2
                                                </td>
    </tr>
    </tbody>
    </table>




```python
rows
```




    [<tr>
     <th>States Affected</th>
     <th>No. of Cases (Lab Confirmed)</th>
     <th>No. of Cases (on admission)</th>
     <th>No. Discharged</th>
     <th>No. of Deaths</th>
     </tr>,
     <tr>
     <td>
                                                     Lagos
                                                 </td>
     <td>100,641
                                                 </td>
     <td>1,810
                                                 </td>
     <td>98,062
                                                 </td>
     <td>769
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     FCT
                                                 </td>
     <td>28,763
                                                 </td>
     <td>63
                                                 </td>
     <td>28,451
                                                 </td>
     <td>249
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Rivers
                                                 </td>
     <td>16,826
                                                 </td>
     <td>127
                                                 </td>
     <td>16,545
                                                 </td>
     <td>154
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Kaduna
                                                 </td>
     <td>11,314
                                                 </td>
     <td>7
                                                 </td>
     <td>11,218
                                                 </td>
     <td>89
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Plateau
                                                 </td>
     <td>10,258
                                                 </td>
     <td>2
                                                 </td>
     <td>10,181
                                                 </td>
     <td>75
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Oyo
                                                 </td>
     <td>10,232
                                                 </td>
     <td>1
                                                 </td>
     <td>10,029
                                                 </td>
     <td>202
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Edo
                                                 </td>
     <td>7,707
                                                 </td>
     <td>11
                                                 </td>
     <td>7,375
                                                 </td>
     <td>321
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Ogun
                                                 </td>
     <td>5,810
                                                 </td>
     <td>11
                                                 </td>
     <td>5,717
                                                 </td>
     <td>82
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Delta
                                                 </td>
     <td>5,413
                                                 </td>
     <td>132
                                                 </td>
     <td>5,170
                                                 </td>
     <td>111
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Ondo
                                                 </td>
     <td>5,173
                                                 </td>
     <td>315
                                                 </td>
     <td>4,749
                                                 </td>
     <td>109
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Kano
                                                 </td>
     <td>5,087
                                                 </td>
     <td>49
                                                 </td>
     <td>4,911
                                                 </td>
     <td>127
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Akwa Ibom
                                                 </td>
     <td>4,659
                                                 </td>
     <td>29
                                                 </td>
     <td>4,586
                                                 </td>
     <td>44
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Kwara
                                                 </td>
     <td>4,640
                                                 </td>
     <td>401
                                                 </td>
     <td>4,175
                                                 </td>
     <td>64
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Osun
                                                 </td>
     <td>3,311
                                                 </td>
     <td>36
                                                 </td>
     <td>3,183
                                                 </td>
     <td>92
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Gombe
                                                 </td>
     <td>3,307
                                                 </td>
     <td>83
                                                 </td>
     <td>3,158
                                                 </td>
     <td>66
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Enugu
                                                 </td>
     <td>2,952
                                                 </td>
     <td>13
                                                 </td>
     <td>2,910
                                                 </td>
     <td>29
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Anambra
                                                 </td>
     <td>2,825
                                                 </td>
     <td>46
                                                 </td>
     <td>2,760
                                                 </td>
     <td>19
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Nasarawa
                                                 </td>
     <td>2,738
                                                 </td>
     <td>354
                                                 </td>
     <td>2,345
                                                 </td>
     <td>39
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Imo
                                                 </td>
     <td>2,648
                                                 </td>
     <td>8
                                                 </td>
     <td>2,582
                                                 </td>
     <td>58
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Katsina
                                                 </td>
     <td>2,418
                                                 </td>
     <td>0
                                                 </td>
     <td>2,381
                                                 </td>
     <td>37
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Abia
                                                 </td>
     <td>2,177
                                                 </td>
     <td>1
                                                 </td>
     <td>2,142
                                                 </td>
     <td>34
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Benue
                                                 </td>
     <td>2,129
                                                 </td>
     <td>340
                                                 </td>
     <td>1,764
                                                 </td>
     <td>25
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Ebonyi
                                                 </td>
     <td>2,064
                                                 </td>
     <td>28
                                                 </td>
     <td>2,004
                                                 </td>
     <td>32
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Ekiti
                                                 </td>
     <td>2,006
                                                 </td>
     <td>52
                                                 </td>
     <td>1,926
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Bauchi
                                                 </td>
     <td>1,967
                                                 </td>
     <td>1
                                                 </td>
     <td>1,942
                                                 </td>
     <td>24
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Borno
                                                 </td>
     <td>1,629
                                                 </td>
     <td>5
                                                 </td>
     <td>1,580
                                                 </td>
     <td>44
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Taraba
                                                 </td>
     <td>1,473
                                                 </td>
     <td>62
                                                 </td>
     <td>1,377
                                                 </td>
     <td>34
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Bayelsa
                                                 </td>
     <td>1,321
                                                 </td>
     <td>1
                                                 </td>
     <td>1,292
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Adamawa
                                                 </td>
     <td>1,203
                                                 </td>
     <td>68
                                                 </td>
     <td>1,103
                                                 </td>
     <td>32
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Niger
                                                 </td>
     <td>1,148
                                                 </td>
     <td>130
                                                 </td>
     <td>998
                                                 </td>
     <td>20
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Cross River
                                                 </td>
     <td>842
                                                 </td>
     <td>8
                                                 </td>
     <td>809
                                                 </td>
     <td>25
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Sokoto
                                                 </td>
     <td>818
                                                 </td>
     <td>0
                                                 </td>
     <td>790
                                                 </td>
     <td>28
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Jigawa
                                                 </td>
     <td>669
                                                 </td>
     <td>2
                                                 </td>
     <td>649
                                                 </td>
     <td>18
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Yobe
                                                 </td>
     <td>609
                                                 </td>
     <td>0
                                                 </td>
     <td>600
                                                 </td>
     <td>9
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Kebbi
                                                 </td>
     <td>480
                                                 </td>
     <td>10
                                                 </td>
     <td>454
                                                 </td>
     <td>16
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Zamfara
                                                 </td>
     <td>375
                                                 </td>
     <td>0
                                                 </td>
     <td>366
                                                 </td>
     <td>9
                                                 </td>
     </tr>,
     <tr>
     <td>
                                                     Kogi
                                                 </td>
     <td>5
                                                 </td>
     <td>0
                                                 </td>
     <td>3
                                                 </td>
     <td>2
                                                 </td>
     </tr>]




```python
for row in rows[1:]:
    cells = row.find_all(['td', 'tr'])
    cell_text = [cell.get_text(strip = True) for cell in cells]
    print (cell_text)
```

    ['Lagos', '100,641', '1,810', '98,062', '769']
    ['FCT', '28,763', '63', '28,451', '249']
    ['Rivers', '16,826', '127', '16,545', '154']
    ['Kaduna', '11,314', '7', '11,218', '89']
    ['Plateau', '10,258', '2', '10,181', '75']
    ['Oyo', '10,232', '1', '10,029', '202']
    ['Edo', '7,707', '11', '7,375', '321']
    ['Ogun', '5,810', '11', '5,717', '82']
    ['Delta', '5,413', '132', '5,170', '111']
    ['Ondo', '5,173', '315', '4,749', '109']
    ['Kano', '5,087', '49', '4,911', '127']
    ['Akwa Ibom', '4,659', '29', '4,586', '44']
    ['Kwara', '4,640', '401', '4,175', '64']
    ['Osun', '3,311', '36', '3,183', '92']
    ['Gombe', '3,307', '83', '3,158', '66']
    ['Enugu', '2,952', '13', '2,910', '29']
    ['Anambra', '2,825', '46', '2,760', '19']
    ['Nasarawa', '2,738', '354', '2,345', '39']
    ['Imo', '2,648', '8', '2,582', '58']
    ['Katsina', '2,418', '0', '2,381', '37']
    ['Abia', '2,177', '1', '2,142', '34']
    ['Benue', '2,129', '340', '1,764', '25']
    ['Ebonyi', '2,064', '28', '2,004', '32']
    ['Ekiti', '2,006', '52', '1,926', '28']
    ['Bauchi', '1,967', '1', '1,942', '24']
    ['Borno', '1,629', '5', '1,580', '44']
    ['Taraba', '1,473', '62', '1,377', '34']
    ['Bayelsa', '1,321', '1', '1,292', '28']
    ['Adamawa', '1,203', '68', '1,103', '32']
    ['Niger', '1,148', '130', '998', '20']
    ['Cross River', '842', '8', '809', '25']
    ['Sokoto', '818', '0', '790', '28']
    ['Jigawa', '669', '2', '649', '18']
    ['Yobe', '609', '0', '600', '9']
    ['Kebbi', '480', '10', '454', '16']
    ['Zamfara', '375', '0', '366', '9']
    ['Kogi', '5', '0', '3', '2']
    


```python
#Exporting into a csv file
```


```python
with open('covid_19.csv','w', encoding = 'utf8', newline= '') as f:
    thewriter = writer(f)
    header = ['States Affected', 'No of cases lab', 'No of Cases', 'No Discharged', 'No of Deaths']
    thewriter.writerow(header)
    
    for row in rows[1:]:
        cells = row.find_all(['td','th'])
        cell_text = [cell.get_text(strip = True) for cell in cells]
        thewriter.writerow(cell_text)
```


```python
#Saving NCDC data as Dataframe // loading csv file
NCDC= pd.read_csv('covid_19.csv')
```


```python
NCDC.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100,641</td>
      <td>1,810</td>
      <td>98,062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28,763</td>
      <td>63</td>
      <td>28,451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16,826</td>
      <td>127</td>
      <td>16,545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11,314</td>
      <td>7</td>
      <td>11,218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10,258</td>
      <td>2</td>
      <td>10,181</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(NCDC.to_string())
```

       States Affected No of cases lab No of Cases No Discharged  No of Deaths
    0            Lagos         100,641       1,810        98,062           769
    1              FCT          28,763          63        28,451           249
    2           Rivers          16,826         127        16,545           154
    3           Kaduna          11,314           7        11,218            89
    4          Plateau          10,258           2        10,181            75
    5              Oyo          10,232           1        10,029           202
    6              Edo           7,707          11         7,375           321
    7             Ogun           5,810          11         5,717            82
    8            Delta           5,413         132         5,170           111
    9             Ondo           5,173         315         4,749           109
    10            Kano           5,087          49         4,911           127
    11       Akwa Ibom           4,659          29         4,586            44
    12           Kwara           4,640         401         4,175            64
    13            Osun           3,311          36         3,183            92
    14           Gombe           3,307          83         3,158            66
    15           Enugu           2,952          13         2,910            29
    16         Anambra           2,825          46         2,760            19
    17        Nasarawa           2,738         354         2,345            39
    18             Imo           2,648           8         2,582            58
    19         Katsina           2,418           0         2,381            37
    20            Abia           2,177           1         2,142            34
    21           Benue           2,129         340         1,764            25
    22          Ebonyi           2,064          28         2,004            32
    23           Ekiti           2,006          52         1,926            28
    24          Bauchi           1,967           1         1,942            24
    25           Borno           1,629           5         1,580            44
    26          Taraba           1,473          62         1,377            34
    27         Bayelsa           1,321           1         1,292            28
    28         Adamawa           1,203          68         1,103            32
    29           Niger           1,148         130           998            20
    30     Cross River             842           8           809            25
    31          Sokoto             818           0           790            28
    32          Jigawa             669           2           649            18
    33            Yobe             609           0           600             9
    34           Kebbi             480          10           454            16
    35         Zamfara             375           0           366             9
    36            Kogi               5           0             3             2
    


```python

```

## B - John Hopkins Data Repository


```python
JHDGlobalConf = pd.read_csv('time_series_covid19_confirmed_global.csv')
```


```python
JHDGlobalConf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>Afghanistan</td>
      <td>33.93911</td>
      <td>67.709953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>180259</td>
      <td>180347</td>
      <td>180419</td>
      <td>180520</td>
      <td>180584</td>
      <td>180615</td>
      <td>180615</td>
      <td>180688</td>
      <td>180741</td>
      <td>180784</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Albania</td>
      <td>41.15330</td>
      <td>20.168300</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>276101</td>
      <td>276101</td>
      <td>276221</td>
      <td>276221</td>
      <td>276310</td>
      <td>276342</td>
      <td>276401</td>
      <td>276415</td>
      <td>276468</td>
      <td>276518</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Algeria</td>
      <td>28.03390</td>
      <td>1.659600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>265877</td>
      <td>265884</td>
      <td>265887</td>
      <td>265889</td>
      <td>265889</td>
      <td>265889</td>
      <td>265897</td>
      <td>265900</td>
      <td>265904</td>
      <td>265909</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Andorra</td>
      <td>42.50630</td>
      <td>1.521800</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>42894</td>
      <td>42894</td>
      <td>42894</td>
      <td>42894</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43224</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Angola</td>
      <td>-11.20270</td>
      <td>17.873900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 873 columns</p>
</div>




```python
JHDRecovery= pd.read_csv('time_series_covid19_recovered_global.csv')
```


```python
JHDRecovery.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>Afghanistan</td>
      <td>33.93911</td>
      <td>67.709953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Albania</td>
      <td>41.15330</td>
      <td>20.168300</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Algeria</td>
      <td>28.03390</td>
      <td>1.659600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Andorra</td>
      <td>42.50630</td>
      <td>1.521800</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Angola</td>
      <td>-11.20270</td>
      <td>17.873900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 873 columns</p>
</div>




```python
JHDeath= pd.read_csv('time_series_covid19_deaths_global.csv')
```


```python
JHDeath.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>Afghanistan</td>
      <td>33.93911</td>
      <td>67.709953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7701</td>
      <td>7705</td>
      <td>7707</td>
      <td>7708</td>
      <td>7708</td>
      <td>7708</td>
      <td>7708</td>
      <td>7709</td>
      <td>7709</td>
      <td>7709</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Albania</td>
      <td>41.15330</td>
      <td>20.168300</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
      <td>3497</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Algeria</td>
      <td>28.03390</td>
      <td>1.659600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
      <td>6875</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Andorra</td>
      <td>42.50630</td>
      <td>1.521800</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
      <td>153</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Angola</td>
      <td>-11.20270</td>
      <td>17.873900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
      <td>1900</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 873 columns</p>
</div>




```python
JHDeath[:0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 873 columns</p>
</div>




```python
import datetime as dt
```


```python
JHDeath.iloc[1:0, 4:873]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>1/28/20</th>
      <th>1/29/20</th>
      <th>1/30/20</th>
      <th>1/31/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<p>0 rows × 869 columns</p>
</div>



#Describing John Hophkin's Data


```python
JHDGlobalConf.describe
```




    <bound method NDFrame.describe of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...   180259   180347   
    1          0        0        0        0        0  ...   276101   276101   
    2          0        0        0        0        0  ...   265877   265884   
    3          0        0        0        0        0  ...    42894    42894   
    4          0        0        0        0        0  ...    99761    99761   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...   657573   657705   
    281        0        0        0        0        0  ...      535      535   
    282        0        0        0        0        0  ...    11822    11822   
    283        0        0        0        0        0  ...   321503   321779   
    284        0        0        0        0        0  ...   252092   252398   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0    180419  180520  180584  180615  180615  180688  180741  180784  
    1    276221  276221  276310  276342  276401  276415  276468  276518  
    2    265887  265889  265889  265889  265897  265900  265904  265909  
    3     42894   42894   43067   43067   43067   43067   43067   43224  
    4     99761   99761   99761   99761   99761   99761   99761   99761  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280  657705  657705  657705  657705  657705  657705  657879  657879  
    281     535     535     535     535     535     535     535     535  
    282   11822   11822   11822   11822   11822   11822   11822   11822  
    283  321915  321915  322207  322207  322207  322207  322562  322790  
    284  252874  253051  253236  253236  253338  253508  253637  253779  
    
    [285 rows x 873 columns]>




```python
JHDGlobalConf.shape
```




    (285, 873)




```python
JHDGlobalConf.columns
```




    Index(['Province/State', 'Country/Region', 'Lat', 'Long', '1/22/20', '1/23/20',
           '1/24/20', '1/25/20', '1/26/20', '1/27/20',
           ...
           '5/30/22', '5/31/22', '6/1/22', '6/2/22', '6/3/22', '6/4/22', '6/5/22',
           '6/6/22', '6/7/22', '6/8/22'],
          dtype='object', length=873)




```python
JHDGlobalConf.isnull
```




    <bound method DataFrame.isnull of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...   180259   180347   
    1          0        0        0        0        0  ...   276101   276101   
    2          0        0        0        0        0  ...   265877   265884   
    3          0        0        0        0        0  ...    42894    42894   
    4          0        0        0        0        0  ...    99761    99761   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...   657573   657705   
    281        0        0        0        0        0  ...      535      535   
    282        0        0        0        0        0  ...    11822    11822   
    283        0        0        0        0        0  ...   321503   321779   
    284        0        0        0        0        0  ...   252092   252398   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0    180419  180520  180584  180615  180615  180688  180741  180784  
    1    276221  276221  276310  276342  276401  276415  276468  276518  
    2    265887  265889  265889  265889  265897  265900  265904  265909  
    3     42894   42894   43067   43067   43067   43067   43067   43224  
    4     99761   99761   99761   99761   99761   99761   99761   99761  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280  657705  657705  657705  657705  657705  657705  657879  657879  
    281     535     535     535     535     535     535     535     535  
    282   11822   11822   11822   11822   11822   11822   11822   11822  
    283  321915  321915  322207  322207  322207  322207  322562  322790  
    284  252874  253051  253236  253236  253338  253508  253637  253779  
    
    [285 rows x 873 columns]>




```python
JHDGlobalConf.notna
```




    <bound method DataFrame.notna of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...   180259   180347   
    1          0        0        0        0        0  ...   276101   276101   
    2          0        0        0        0        0  ...   265877   265884   
    3          0        0        0        0        0  ...    42894    42894   
    4          0        0        0        0        0  ...    99761    99761   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...   657573   657705   
    281        0        0        0        0        0  ...      535      535   
    282        0        0        0        0        0  ...    11822    11822   
    283        0        0        0        0        0  ...   321503   321779   
    284        0        0        0        0        0  ...   252092   252398   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0    180419  180520  180584  180615  180615  180688  180741  180784  
    1    276221  276221  276310  276342  276401  276415  276468  276518  
    2    265887  265889  265889  265889  265897  265900  265904  265909  
    3     42894   42894   43067   43067   43067   43067   43067   43224  
    4     99761   99761   99761   99761   99761   99761   99761   99761  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280  657705  657705  657705  657705  657705  657705  657879  657879  
    281     535     535     535     535     535     535     535     535  
    282   11822   11822   11822   11822   11822   11822   11822   11822  
    283  321915  321915  322207  322207  322207  322207  322562  322790  
    284  252874  253051  253236  253236  253338  253508  253637  253779  
    
    [285 rows x 873 columns]>




```python
JHDRecovery.describe
```




    <bound method NDFrame.describe of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    265            NaN    West Bank and Gaza  31.952200   35.233200        0   
    266            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    267            NaN                 Yemen  15.552727   48.516388        0   
    268            NaN                Zambia -13.133897   27.849332        0   
    269            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...        0        0   
    1          0        0        0        0        0  ...        0        0   
    2          0        0        0        0        0  ...        0        0   
    3          0        0        0        0        0  ...        0        0   
    4          0        0        0        0        0  ...        0        0   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    265        0        0        0        0        0  ...        0        0   
    266        0        0        0        0        0  ...        0        0   
    267        0        0        0        0        0  ...        0        0   
    268        0        0        0        0        0  ...        0        0   
    269        0        0        0        0        0  ...        0        0   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0         0       0       0       0       0       0       0       0  
    1         0       0       0       0       0       0       0       0  
    2         0       0       0       0       0       0       0       0  
    3         0       0       0       0       0       0       0       0  
    4         0       0       0       0       0       0       0       0  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    265       0       0       0       0       0       0       0       0  
    266       0       0       0       0       0       0       0       0  
    267       0       0       0       0       0       0       0       0  
    268       0       0       0       0       0       0       0       0  
    269       0       0       0       0       0       0       0       0  
    
    [270 rows x 873 columns]>




```python
JHDRecovery.shape
```




    (270, 873)




```python
JHDRecovery.columns
```




    Index(['Province/State', 'Country/Region', 'Lat', 'Long', '1/22/20', '1/23/20',
           '1/24/20', '1/25/20', '1/26/20', '1/27/20',
           ...
           '5/30/22', '5/31/22', '6/1/22', '6/2/22', '6/3/22', '6/4/22', '6/5/22',
           '6/6/22', '6/7/22', '6/8/22'],
          dtype='object', length=873)




```python
JHDRecovery.isnull
```




    <bound method DataFrame.isnull of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    265            NaN    West Bank and Gaza  31.952200   35.233200        0   
    266            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    267            NaN                 Yemen  15.552727   48.516388        0   
    268            NaN                Zambia -13.133897   27.849332        0   
    269            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...        0        0   
    1          0        0        0        0        0  ...        0        0   
    2          0        0        0        0        0  ...        0        0   
    3          0        0        0        0        0  ...        0        0   
    4          0        0        0        0        0  ...        0        0   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    265        0        0        0        0        0  ...        0        0   
    266        0        0        0        0        0  ...        0        0   
    267        0        0        0        0        0  ...        0        0   
    268        0        0        0        0        0  ...        0        0   
    269        0        0        0        0        0  ...        0        0   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0         0       0       0       0       0       0       0       0  
    1         0       0       0       0       0       0       0       0  
    2         0       0       0       0       0       0       0       0  
    3         0       0       0       0       0       0       0       0  
    4         0       0       0       0       0       0       0       0  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    265       0       0       0       0       0       0       0       0  
    266       0       0       0       0       0       0       0       0  
    267       0       0       0       0       0       0       0       0  
    268       0       0       0       0       0       0       0       0  
    269       0       0       0       0       0       0       0       0  
    
    [270 rows x 873 columns]>




```python
JHDRecovery.notna
```




    <bound method DataFrame.notna of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    265            NaN    West Bank and Gaza  31.952200   35.233200        0   
    266            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    267            NaN                 Yemen  15.552727   48.516388        0   
    268            NaN                Zambia -13.133897   27.849332        0   
    269            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...        0        0   
    1          0        0        0        0        0  ...        0        0   
    2          0        0        0        0        0  ...        0        0   
    3          0        0        0        0        0  ...        0        0   
    4          0        0        0        0        0  ...        0        0   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    265        0        0        0        0        0  ...        0        0   
    266        0        0        0        0        0  ...        0        0   
    267        0        0        0        0        0  ...        0        0   
    268        0        0        0        0        0  ...        0        0   
    269        0        0        0        0        0  ...        0        0   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0         0       0       0       0       0       0       0       0  
    1         0       0       0       0       0       0       0       0  
    2         0       0       0       0       0       0       0       0  
    3         0       0       0       0       0       0       0       0  
    4         0       0       0       0       0       0       0       0  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    265       0       0       0       0       0       0       0       0  
    266       0       0       0       0       0       0       0       0  
    267       0       0       0       0       0       0       0       0  
    268       0       0       0       0       0       0       0       0  
    269       0       0       0       0       0       0       0       0  
    
    [270 rows x 873 columns]>




```python
JHDeath.describe
```




    <bound method NDFrame.describe of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...     7701     7705   
    1          0        0        0        0        0  ...     3497     3497   
    2          0        0        0        0        0  ...     6875     6875   
    3          0        0        0        0        0  ...      153      153   
    4          0        0        0        0        0  ...     1900     1900   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...     5660     5660   
    281        0        0        0        0        0  ...        0        0   
    282        0        0        0        0        0  ...     2149     2149   
    283        0        0        0        0        0  ...     3985     3987   
    284        0        0        0        0        0  ...     5500     5503   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0      7707    7708    7708    7708    7708    7709    7709    7709  
    1      3497    3497    3497    3497    3497    3497    3497    3497  
    2      6875    6875    6875    6875    6875    6875    6875    6875  
    3       153     153     153     153     153     153     153     153  
    4      1900    1900    1900    1900    1900    1900    1900    1900  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280    5660    5660    5660    5660    5660    5660    5660    5660  
    281       0       0       0       0       0       0       0       0  
    282    2149    2149    2149    2149    2149    2149    2149    2149  
    283    3987    3987    3988    3988    3988    3988    3988    3988  
    284    5507    5508    5509    5509    5510    5513    5515    5515  
    
    [285 rows x 873 columns]>




```python
JHDeath.shape
```




    (285, 873)




```python
JHDeath.columns
```




    Index(['Province/State', 'Country/Region', 'Lat', 'Long', '1/22/20', '1/23/20',
           '1/24/20', '1/25/20', '1/26/20', '1/27/20',
           ...
           '5/30/22', '5/31/22', '6/1/22', '6/2/22', '6/3/22', '6/4/22', '6/5/22',
           '6/6/22', '6/7/22', '6/8/22'],
          dtype='object', length=873)




```python
JHDeath.isnull
```




    <bound method DataFrame.isnull of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...     7701     7705   
    1          0        0        0        0        0  ...     3497     3497   
    2          0        0        0        0        0  ...     6875     6875   
    3          0        0        0        0        0  ...      153      153   
    4          0        0        0        0        0  ...     1900     1900   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...     5660     5660   
    281        0        0        0        0        0  ...        0        0   
    282        0        0        0        0        0  ...     2149     2149   
    283        0        0        0        0        0  ...     3985     3987   
    284        0        0        0        0        0  ...     5500     5503   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0      7707    7708    7708    7708    7708    7709    7709    7709  
    1      3497    3497    3497    3497    3497    3497    3497    3497  
    2      6875    6875    6875    6875    6875    6875    6875    6875  
    3       153     153     153     153     153     153     153     153  
    4      1900    1900    1900    1900    1900    1900    1900    1900  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280    5660    5660    5660    5660    5660    5660    5660    5660  
    281       0       0       0       0       0       0       0       0  
    282    2149    2149    2149    2149    2149    2149    2149    2149  
    283    3987    3987    3988    3988    3988    3988    3988    3988  
    284    5507    5508    5509    5509    5510    5513    5515    5515  
    
    [285 rows x 873 columns]>




```python
JHDeath.notna
```




    <bound method DataFrame.notna of     Province/State        Country/Region        Lat        Long  1/22/20  \
    0              NaN           Afghanistan  33.939110   67.709953        0   
    1              NaN               Albania  41.153300   20.168300        0   
    2              NaN               Algeria  28.033900    1.659600        0   
    3              NaN               Andorra  42.506300    1.521800        0   
    4              NaN                Angola -11.202700   17.873900        0   
    ..             ...                   ...        ...         ...      ...   
    280            NaN    West Bank and Gaza  31.952200   35.233200        0   
    281            NaN  Winter Olympics 2022  39.904200  116.407400        0   
    282            NaN                 Yemen  15.552727   48.516388        0   
    283            NaN                Zambia -13.133897   27.849332        0   
    284            NaN              Zimbabwe -19.015438   29.154857        0   
    
         1/23/20  1/24/20  1/25/20  1/26/20  1/27/20  ...  5/30/22  5/31/22  \
    0          0        0        0        0        0  ...     7701     7705   
    1          0        0        0        0        0  ...     3497     3497   
    2          0        0        0        0        0  ...     6875     6875   
    3          0        0        0        0        0  ...      153      153   
    4          0        0        0        0        0  ...     1900     1900   
    ..       ...      ...      ...      ...      ...  ...      ...      ...   
    280        0        0        0        0        0  ...     5660     5660   
    281        0        0        0        0        0  ...        0        0   
    282        0        0        0        0        0  ...     2149     2149   
    283        0        0        0        0        0  ...     3985     3987   
    284        0        0        0        0        0  ...     5500     5503   
    
         6/1/22  6/2/22  6/3/22  6/4/22  6/5/22  6/6/22  6/7/22  6/8/22  
    0      7707    7708    7708    7708    7708    7709    7709    7709  
    1      3497    3497    3497    3497    3497    3497    3497    3497  
    2      6875    6875    6875    6875    6875    6875    6875    6875  
    3       153     153     153     153     153     153     153     153  
    4      1900    1900    1900    1900    1900    1900    1900    1900  
    ..      ...     ...     ...     ...     ...     ...     ...     ...  
    280    5660    5660    5660    5660    5660    5660    5660    5660  
    281       0       0       0       0       0       0       0       0  
    282    2149    2149    2149    2149    2149    2149    2149    2149  
    283    3987    3987    3988    3988    3988    3988    3988    3988  
    284    5507    5508    5509    5509    5510    5513    5515    5515  
    
    [285 rows x 873 columns]>



## C-External Data


```python
CovidBudget = pd.read_csv('Budget data.csv')
```


```python
CovidBudget.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>states</th>
      <th>Initial_budget (Bn)</th>
      <th>Revised_budget (Bn)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Abia</td>
      <td>136.60</td>
      <td>102.70</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adamawa</td>
      <td>183.30</td>
      <td>139.31</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Akwa-Ibom</td>
      <td>597.73</td>
      <td>366.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Anambra</td>
      <td>137.10</td>
      <td>112.80</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bauchi</td>
      <td>167.20</td>
      <td>128.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidBudget.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 3 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   states               37 non-null     object 
     1   Initial_budget (Bn)  37 non-null     float64
     2   Revised_budget (Bn)  37 non-null     float64
    dtypes: float64(2), object(1)
    memory usage: 1016.0+ bytes
    


```python
CovidBudget.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Initial_budget (Bn)</th>
      <th>Revised_budget (Bn)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>37.00000</td>
      <td>37.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>276.22027</td>
      <td>171.092432</td>
    </tr>
    <tr>
      <th>std</th>
      <td>299.37630</td>
      <td>142.974439</td>
    </tr>
    <tr>
      <th>min</th>
      <td>108.00000</td>
      <td>62.960000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>152.92000</td>
      <td>108.300000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>183.30000</td>
      <td>128.800000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>242.18000</td>
      <td>174.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1680.00000</td>
      <td>920.500000</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidOther = pd.read_csv('covid_external.csv')
```


```python
CovidOther.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>states</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>FCT</td>
      <td>North Central</td>
      <td>4865000</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Plateau</td>
      <td>North Central</td>
      <td>4766000</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kwara</td>
      <td>North Central</td>
      <td>3524000</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nassarawa</td>
      <td>North Central</td>
      <td>2783000</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Niger</td>
      <td>North Central</td>
      <td>6260000</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.84</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidOther.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3.700000e+01</td>
      <td>37.000000</td>
      <td>37.000000</td>
      <td>37.000000</td>
      <td>37.000000</td>
      <td>37.000000</td>
      <td>37.0</td>
      <td>37.000000</td>
      <td>37.000000</td>
      <td>37.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>5.843892e+06</td>
      <td>0.502703</td>
      <td>0.502703</td>
      <td>0.500000</td>
      <td>0.502703</td>
      <td>0.502703</td>
      <td>0.5</td>
      <td>0.502703</td>
      <td>0.502703</td>
      <td>0.954054</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.622344e+06</td>
      <td>0.301373</td>
      <td>0.301373</td>
      <td>0.299073</td>
      <td>0.301373</td>
      <td>0.301373</td>
      <td>0.3</td>
      <td>0.301373</td>
      <td>0.301373</td>
      <td>0.100539</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.606000e+06</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.790000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>4.272000e+06</td>
      <td>0.300000</td>
      <td>0.300000</td>
      <td>0.300000</td>
      <td>0.300000</td>
      <td>0.300000</td>
      <td>0.3</td>
      <td>0.300000</td>
      <td>0.300000</td>
      <td>0.870000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>5.185000e+06</td>
      <td>0.500000</td>
      <td>0.500000</td>
      <td>0.500000</td>
      <td>0.500000</td>
      <td>0.500000</td>
      <td>0.5</td>
      <td>0.500000</td>
      <td>0.500000</td>
      <td>0.930000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.376000e+06</td>
      <td>0.800000</td>
      <td>0.800000</td>
      <td>0.700000</td>
      <td>0.800000</td>
      <td>0.800000</td>
      <td>0.8</td>
      <td>0.800000</td>
      <td>0.800000</td>
      <td>1.040000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.472600e+07</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.0</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.140000</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidOther.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 12 columns):
     #   Column                   Non-Null Count  Dtype  
    ---  ------                   --------------  -----  
     0   states                   37 non-null     object 
     1   region                   37 non-null     object 
     2   Population               37 non-null     int64  
     3   Overall CCVI Index       37 non-null     float64
     4   Age                      37 non-null     float64
     5   Epidemiological          37 non-null     float64
     6   Fragility                37 non-null     float64
     7   Health System            37 non-null     float64
     8   Population Density       37 non-null     float64
     9   Socio-Economic           37 non-null     float64
     10   Transport Availability  37 non-null     float64
     11  Acute IHR                37 non-null     float64
    dtypes: float64(9), int64(1), object(2)
    memory usage: 3.6+ KB
    


```python
CovidNig = pd.read_csv('covidnig.csv')
```


```python
CovidNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26,708</td>
      <td>2,435</td>
      <td>24,037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9,627</td>
      <td>2,840</td>
      <td>6,694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4,504</td>
      <td>579</td>
      <td>3,877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4,262</td>
      <td>280</td>
      <td>3,948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3,788</td>
      <td>368</td>
      <td>3,374</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidNig.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 5 columns):
     #   Column                        Non-Null Count  Dtype 
    ---  ------                        --------------  ----- 
     0   States Affected               37 non-null     object
     1   No. of Cases (Lab Confirmed)  37 non-null     object
     2   No. of Cases (on admission)   37 non-null     object
     3   No. Discharged                37 non-null     object
     4   No. of Deaths                 37 non-null     int64 
    dtypes: int64(1), object(4)
    memory usage: 1.6+ KB
    


```python
CovidNig.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>37.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>33.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>41.797794</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>21.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>36.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>236.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
RealGDP = pd.read_csv('RealGDP.csv')
```


```python
RealGDP.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Q1</th>
      <th>Q2</th>
      <th>Q3</th>
      <th>Q4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2014</td>
      <td>15438679.50</td>
      <td>16084622.31</td>
      <td>17479127.58</td>
      <td>18150356.45</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015</td>
      <td>16050601.38</td>
      <td>16463341.91</td>
      <td>17976234.59</td>
      <td>18533752.07</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016</td>
      <td>15943714.54</td>
      <td>16218542.41</td>
      <td>17555441.69</td>
      <td>18213537.29</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017</td>
      <td>15797965.83</td>
      <td>16334719.27</td>
      <td>17760228.17</td>
      <td>18598067.07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2018</td>
      <td>16096654.19</td>
      <td>16580508.07</td>
      <td>18081342.10</td>
      <td>19041437.59</td>
    </tr>
  </tbody>
</table>
</div>




```python
RealGDP.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Q1</th>
      <th>Q2</th>
      <th>Q3</th>
      <th>Q4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7.000000</td>
      <td>7.000000e+00</td>
      <td>7.000000e+00</td>
      <td>7.000000e+00</td>
      <td>7.000000e+00</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2017.000000</td>
      <td>1.607174e+07</td>
      <td>1.635760e+07</td>
      <td>1.788093e+07</td>
      <td>1.600959e+07</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.160247</td>
      <td>4.225676e+05</td>
      <td>3.423407e+05</td>
      <td>3.442170e+05</td>
      <td>7.075830e+06</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2014.000000</td>
      <td>1.543868e+07</td>
      <td>1.589000e+07</td>
      <td>1.747913e+07</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2015.500000</td>
      <td>1.587084e+07</td>
      <td>1.615158e+07</td>
      <td>1.765783e+07</td>
      <td>1.818195e+07</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2017.000000</td>
      <td>1.605060e+07</td>
      <td>1.633472e+07</td>
      <td>1.782000e+07</td>
      <td>1.853375e+07</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2018.500000</td>
      <td>1.626560e+07</td>
      <td>1.652192e+07</td>
      <td>1.802879e+07</td>
      <td>1.881975e+07</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2020.000000</td>
      <td>1.674000e+07</td>
      <td>1.693143e+07</td>
      <td>1.849411e+07</td>
      <td>1.953000e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
RealGDP.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7 entries, 0 to 6
    Data columns (total 5 columns):
     #   Column  Non-Null Count  Dtype  
    ---  ------  --------------  -----  
     0   Year    7 non-null      int64  
     1   Q1      7 non-null      float64
     2   Q2      7 non-null      float64
     3   Q3      7 non-null      float64
     4   Q4      7 non-null      float64
    dtypes: float64(4), int64(1)
    memory usage: 408.0 bytes
    

# SECTION B: Data Cleaning and Preparation


```python
NCDC= pd.read_csv('covid_19.csv')
```


```python
NCDC.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100,641</td>
      <td>1,810</td>
      <td>98,062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28,763</td>
      <td>63</td>
      <td>28,451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16,826</td>
      <td>127</td>
      <td>16,545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11,314</td>
      <td>7</td>
      <td>11,218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10,258</td>
      <td>2</td>
      <td>10,181</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDC['No of cases lab'] = NCDC['No of cases lab'].str.replace(',', '').astype(int)
```


```python
NCDC.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98,062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28,451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16,545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11,218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10,181</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDC['No Discharged'] = NCDC['No Discharged'].str.replace(',', '').astype(int)
```


```python
NCDC.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 37 entries, 0 to 36
    Data columns (total 5 columns):
     #   Column           Non-Null Count  Dtype 
    ---  ------           --------------  ----- 
     0   States Affected  37 non-null     object
     1   No of cases lab  37 non-null     int32 
     2   No of Cases      37 non-null     object
     3   No Discharged    37 non-null     int32 
     4   No of Deaths     37 non-null     int64 
    dtypes: int32(2), int64(1), object(2)
    memory usage: 1.3+ KB
    

### Extracting daily data for Nigeria from the Global daily cases data


```python
JHDGlobalConf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>Afghanistan</td>
      <td>33.93911</td>
      <td>67.709953</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>180259</td>
      <td>180347</td>
      <td>180419</td>
      <td>180520</td>
      <td>180584</td>
      <td>180615</td>
      <td>180615</td>
      <td>180688</td>
      <td>180741</td>
      <td>180784</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>Albania</td>
      <td>41.15330</td>
      <td>20.168300</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>276101</td>
      <td>276101</td>
      <td>276221</td>
      <td>276221</td>
      <td>276310</td>
      <td>276342</td>
      <td>276401</td>
      <td>276415</td>
      <td>276468</td>
      <td>276518</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>Algeria</td>
      <td>28.03390</td>
      <td>1.659600</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>265877</td>
      <td>265884</td>
      <td>265887</td>
      <td>265889</td>
      <td>265889</td>
      <td>265889</td>
      <td>265897</td>
      <td>265900</td>
      <td>265904</td>
      <td>265909</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>Andorra</td>
      <td>42.50630</td>
      <td>1.521800</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>42894</td>
      <td>42894</td>
      <td>42894</td>
      <td>42894</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43067</td>
      <td>43224</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>Angola</td>
      <td>-11.20270</td>
      <td>17.873900</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
      <td>99761</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 873 columns</p>
</div>




```python
JHDGlobalConf.loc[204]
```




    Province/State        NaN
    Country/Region    Nigeria
    Lat                 9.082
    Long               8.6753
    1/22/20                 0
                       ...   
    6/4/22             256148
    6/5/22             256148
    6/6/22             256148
    6/7/22             256227
    6/8/22             256227
    Name: 204, Length: 873, dtype: object




```python
#Nigeria is located on row number 204

NigGloConfirm= JHDGlobalConf.loc[204]
```


```python
NigGloConfirm.head()
```




    Province/State        NaN
    Country/Region    Nigeria
    Lat                 9.082
    Long               8.6753
    1/22/20                 0
    Name: 204, dtype: object




```python
pd.DataFrame(NigGloConfirm)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Province/State</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Country/Region</th>
      <td>Nigeria</td>
    </tr>
    <tr>
      <th>Lat</th>
      <td>9.082</td>
    </tr>
    <tr>
      <th>Long</th>
      <td>8.6753</td>
    </tr>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>6/4/22</th>
      <td>256148</td>
    </tr>
    <tr>
      <th>6/5/22</th>
      <td>256148</td>
    </tr>
    <tr>
      <th>6/6/22</th>
      <td>256148</td>
    </tr>
    <tr>
      <th>6/7/22</th>
      <td>256227</td>
    </tr>
    <tr>
      <th>6/8/22</th>
      <td>256227</td>
    </tr>
  </tbody>
</table>
<p>873 rows × 1 columns</p>
</div>




```python
A= JHDGlobalConf.groupby('Country/Region')
```


```python
type(A)
```




    pandas.core.groupby.generic.DataFrameGroupBy




```python
NigConf= A.get_group('Nigeria')
```


```python
NigConf
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>204</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>256028</td>
      <td>256028</td>
      <td>256028</td>
      <td>256113</td>
      <td>256113</td>
      <td>256148</td>
      <td>256148</td>
      <td>256148</td>
      <td>256227</td>
      <td>256227</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 873 columns</p>
</div>




```python
B = JHDRecovery.groupby('Country/Region')
```


```python
NigRecov = B.get_group('Nigeria')
```


```python
NigRecov
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>189</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 873 columns</p>
</div>




```python
C= JHDeath.groupby('Country/Region')
```


```python
NigDeath= C.get_group('Nigeria')
```


```python
NigDeath
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>204</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3148</td>
      <td>3148</td>
      <td>3148</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 873 columns</p>
</div>




```python
ABC= pd.concat([NigConf, NigRecov, NigDeath])
```


```python
ABC
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Province/State</th>
      <th>Country/Region</th>
      <th>Lat</th>
      <th>Long</th>
      <th>1/22/20</th>
      <th>1/23/20</th>
      <th>1/24/20</th>
      <th>1/25/20</th>
      <th>1/26/20</th>
      <th>1/27/20</th>
      <th>...</th>
      <th>5/30/22</th>
      <th>5/31/22</th>
      <th>6/1/22</th>
      <th>6/2/22</th>
      <th>6/3/22</th>
      <th>6/4/22</th>
      <th>6/5/22</th>
      <th>6/6/22</th>
      <th>6/7/22</th>
      <th>6/8/22</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>204</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>256028</td>
      <td>256028</td>
      <td>256028</td>
      <td>256113</td>
      <td>256113</td>
      <td>256148</td>
      <td>256148</td>
      <td>256148</td>
      <td>256227</td>
      <td>256227</td>
    </tr>
    <tr>
      <th>189</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>204</th>
      <td>NaN</td>
      <td>Nigeria</td>
      <td>9.082</td>
      <td>8.6753</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3143</td>
      <td>3148</td>
      <td>3148</td>
      <td>3148</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 873 columns</p>
</div>




```python
CoNig= pd.DataFrame(NigGloConfirm)
```


```python
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Province/State</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Country/Region</th>
      <td>Nigeria</td>
    </tr>
    <tr>
      <th>Lat</th>
      <td>9.082</td>
    </tr>
    <tr>
      <th>Long</th>
      <td>8.6753</td>
    </tr>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
CoNig= CoNig.drop(['Province/State', 'Country/Region', 'Lat', 'Long'])
```


```python
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/23/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/24/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/25/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/26/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
list(CoNig)
```




    [204]




```python
CoNig= CoNig.reset_index()
```


```python
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1/22/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1/23/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1/24/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1/25/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1/26/20</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
CoNig.rename(columns = {'index':'Date', 204:'Cases'}, inplace = True)
```


```python
list(CoNig)
```




    ['Date', 'Cases']




```python
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1/22/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1/23/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1/24/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1/25/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1/26/20</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
pd.to_datetime(CoNig['Date'])
```




    0     2020-01-22
    1     2020-01-23
    2     2020-01-24
    3     2020-01-25
    4     2020-01-26
             ...    
    864   2022-06-04
    865   2022-06-05
    866   2022-06-06
    867   2022-06-07
    868   2022-06-08
    Name: Date, Length: 869, dtype: datetime64[ns]




```python
CoNig['Date'] = pd.to_datetime(CoNig['Date'])
```


```python
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Extracting Nigeria's Data and formarting to the righr formart in John hophkin's Recovery Data
NigGloRecov= JHDRecovery.loc[204]
```


```python
NigGloRecov.head()
```




    Province/State           NaN
    Country/Region        Russia
    Lat                 61.52401
    Long              105.318756
    1/22/20                    0
    Name: 204, dtype: object




```python
ReNig= pd.DataFrame(NigGloRecov)
```


```python
ReNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Province/State</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Country/Region</th>
      <td>Russia</td>
    </tr>
    <tr>
      <th>Lat</th>
      <td>61.52401</td>
    </tr>
    <tr>
      <th>Long</th>
      <td>105.318756</td>
    </tr>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
ReNig= ReNig.drop(['Province/State', 'Country/Region', 'Lat', 'Long'])
```


```python
ReNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/23/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/24/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/25/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/26/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
ReNig= ReNig.reset_index()
```


```python
list(ReNig)
```




    ['index', 204]




```python
ReNig.rename(columns = {'index':'Date', 204:'Cases'}, inplace = True)
```


```python
ReNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1/22/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1/23/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1/24/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1/25/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1/26/20</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
ReNig['Date'] = pd.to_datetime(ReNig['Date'])
```


```python
ReNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Extracting Nigeria's Data and formarting to the righr formart in John hophkin's Death Data
NigGloDeath= JHDeath.loc[204]
```


```python
NigGloDeath.head()
```




    Province/State        NaN
    Country/Region    Nigeria
    Lat                 9.082
    Long               8.6753
    1/22/20                 0
    Name: 204, dtype: object




```python
DeNig= pd.DataFrame(NigGloDeath)
```


```python
DeNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Province/State</th>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Country/Region</th>
      <td>Nigeria</td>
    </tr>
    <tr>
      <th>Lat</th>
      <td>9.082</td>
    </tr>
    <tr>
      <th>Long</th>
      <td>8.6753</td>
    </tr>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
DeNig= DeNig.drop(['Province/State', 'Country/Region', 'Lat', 'Long'])
```


```python
DeNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>204</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1/22/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/23/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/24/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/25/20</th>
      <td>0</td>
    </tr>
    <tr>
      <th>1/26/20</th>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
DeNig= DeNig.reset_index()
```


```python
list(DeNig)
```




    ['index', 204]




```python
DeNig.rename(columns = {'index':'Date', 204:'Cases'}, inplace = True)
```


```python
DeNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1/22/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1/23/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1/24/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1/25/20</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1/26/20</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
DeNig['Date']= pd.to_datetime(DeNig['Date'])
```


```python
DeNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Pandas DataFrame for Daily Confirmed Cases in Nigeria. Columns are Date and Cases
CoNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
CoNig.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 869 entries, 0 to 868
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype         
    ---  ------  --------------  -----         
     0   Date    869 non-null    datetime64[ns]
     1   Cases   869 non-null    object        
    dtypes: datetime64[ns](1), object(1)
    memory usage: 13.7+ KB
    


```python
#Pandas DataFrame for Daily Recovery Cases in Nigeria. Columns are Date and Cases
ReNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
ReNig.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 869 entries, 0 to 868
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype         
    ---  ------  --------------  -----         
     0   Date    869 non-null    datetime64[ns]
     1   Cases   869 non-null    object        
    dtypes: datetime64[ns](1), object(1)
    memory usage: 13.7+ KB
    


```python
#Pandas DataFrame for Daily Recovery Cases in Nigeria. Columns are Date and Cases
DeNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
DeNig.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 869 entries, 0 to 868
    Data columns (total 2 columns):
     #   Column  Non-Null Count  Dtype         
    ---  ------  --------------  -----         
     0   Date    869 non-null    datetime64[ns]
     1   Cases   869 non-null    object        
    dtypes: datetime64[ns](1), object(1)
    memory usage: 13.7+ KB
    

## Data Cleaning Checkup before Analysis


```python
NCDC.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26,708</td>
      <td>2,435</td>
      <td>24,037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9,627</td>
      <td>2,840</td>
      <td>6,694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4,504</td>
      <td>579</td>
      <td>3,877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4,262</td>
      <td>280</td>
      <td>3,948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3,788</td>
      <td>368</td>
      <td>3,374</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Cleaning DataFrame 'CovidNig': Removing Commas
CovidNig['No. of Cases (Lab Confirmed)'] = CovidNig['No. of Cases (Lab Confirmed)'].str.replace(',', '').astype(int)
```


```python
CovidNig['No. of Cases (on admission)'] = CovidNig['No. of Cases (on admission)'].str.replace(',', '').astype(int)
```


```python
CovidNig['No. Discharged'] = CovidNig['No. Discharged'].str.replace(',', '').astype(int)
```


```python
CovidNig.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4262</td>
      <td>280</td>
      <td>3948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>



# SECTION C: ANALYSIS


```python
#Generate a plot that shows the Top 10 states in terms of Confirmed Covid cases by Laboratory test
```


```python
NCDC.groupby(['States Affected'])['No of cases lab'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_136_1.png)
    



```python
CovidNig.groupby(['States Affected'])['No. of Cases (Lab Confirmed)'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_137_1.png)
    



```python
NCDC.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232</td>
      <td>1</td>
      <td>10029</td>
      <td>202</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707</td>
      <td>11</td>
      <td>7375</td>
      <td>321</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810</td>
      <td>11</td>
      <td>5717</td>
      <td>82</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413</td>
      <td>132</td>
      <td>5170</td>
      <td>111</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173</td>
      <td>315</td>
      <td>4749</td>
      <td>109</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087</td>
      <td>49</td>
      <td>4911</td>
      <td>127</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Akwa Ibom</td>
      <td>4659</td>
      <td>29</td>
      <td>4586</td>
      <td>44</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Kwara</td>
      <td>4640</td>
      <td>401</td>
      <td>4175</td>
      <td>64</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Osun</td>
      <td>3311</td>
      <td>36</td>
      <td>3183</td>
      <td>92</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>3307</td>
      <td>83</td>
      <td>3158</td>
      <td>66</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Enugu</td>
      <td>2952</td>
      <td>13</td>
      <td>2910</td>
      <td>29</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Anambra</td>
      <td>2825</td>
      <td>46</td>
      <td>2760</td>
      <td>19</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Nasarawa</td>
      <td>2738</td>
      <td>354</td>
      <td>2345</td>
      <td>39</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Imo</td>
      <td>2648</td>
      <td>8</td>
      <td>2582</td>
      <td>58</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Katsina</td>
      <td>2418</td>
      <td>0</td>
      <td>2381</td>
      <td>37</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDCPlot= NCDC[0:11]
```


```python
NCDCPlot
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232</td>
      <td>1</td>
      <td>10029</td>
      <td>202</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707</td>
      <td>11</td>
      <td>7375</td>
      <td>321</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810</td>
      <td>11</td>
      <td>5717</td>
      <td>82</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413</td>
      <td>132</td>
      <td>5170</td>
      <td>111</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173</td>
      <td>315</td>
      <td>4749</td>
      <td>109</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087</td>
      <td>49</td>
      <td>4911</td>
      <td>127</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDCPlot.groupby(['States Affected'])['No of cases lab'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_141_1.png)
    



```python
CovidNig.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4262</td>
      <td>280</td>
      <td>3948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Rivers</td>
      <td>3279</td>
      <td>232</td>
      <td>2987</td>
      <td>60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>2768</td>
      <td>52</td>
      <td>2603</td>
      <td>113</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>2382</td>
      <td>174</td>
      <td>2175</td>
      <td>33</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Kano</td>
      <td>2032</td>
      <td>198</td>
      <td>1778</td>
      <td>56</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Delta</td>
      <td>1843</td>
      <td>57</td>
      <td>1737</td>
      <td>49</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ondo</td>
      <td>1793</td>
      <td>62</td>
      <td>1690</td>
      <td>41</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Katsina</td>
      <td>1405</td>
      <td>214</td>
      <td>1167</td>
      <td>24</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Enugu</td>
      <td>1376</td>
      <td>34</td>
      <td>1321</td>
      <td>21</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Kwara</td>
      <td>1296</td>
      <td>171</td>
      <td>1094</td>
      <td>31</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>1164</td>
      <td>183</td>
      <td>950</td>
      <td>31</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ebonyi</td>
      <td>1091</td>
      <td>24</td>
      <td>1037</td>
      <td>30</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Abia</td>
      <td>980</td>
      <td>25</td>
      <td>945</td>
      <td>10</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Osun</td>
      <td>979</td>
      <td>20</td>
      <td>937</td>
      <td>22</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Bauchi</td>
      <td>897</td>
      <td>108</td>
      <td>775</td>
      <td>14</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Borno</td>
      <td>778</td>
      <td>37</td>
      <td>705</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidPlot= CovidNig[0:11]
```


```python
CovidPlot.groupby(['States Affected'])['No. of Cases (Lab Confirmed)'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_144_1.png)
    


## Summary of the first 4 plots

The graph of ploting the top 10 states in Nigeria with Covid cases via Lab confrimation. This can be done using two dataframes: 1. NCDC which is the dataframe scrapped from the NCDC website and 2. CovidNig which is the dataframe from the external dataframe. 

Using this two dataframe will give room for comparison and drawing of inferences.

### Details of Plots
Plot1 and 2= the graph is a bar chart showing the mean value of the No of Case in each states using NCDC and CovidNig. The top 10 states in 
NCDC are: Lagos, FCT, Rivers, Kaduna, Oyo, Plateau, Edo, Ogun, Delta, Kano and Ondo. and 
CovidNig are: Lagos, FCT, Kaduna, Plateau, Oyo, Rivers, Edo, Ogun, Kano, Delta and Ondo.

Plot3 and 4= these bar charts are just to show the Top10 states more explicitly.

### Inference
-It can be said that the Top 2 states in both dataFrames are Lagos and FCT. With Lagos ranking first in both dataframes.
-Rank of states like Rivers, Kaduna and Plateau weren't constant; which will put one a state of which data source is the most accurate.
-The bottom region in both data sources showed that Ogun, Kano and Delta evening though the position of Kano and Delta interchanged in NCDC and CovidNig data sources.


```python
#Generate a plot that shows the Top 10 states in terms of Discharged Covid cases.
```


```python
NCDC.groupby(['States Affected'])['No Discharged'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_147_1.png)
    



```python
NCDCsorted = NCDC.sort_values("No Discharged", ascending=False)
```


```python
NCDCsorted.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232</td>
      <td>1</td>
      <td>10029</td>
      <td>202</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707</td>
      <td>11</td>
      <td>7375</td>
      <td>321</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810</td>
      <td>11</td>
      <td>5717</td>
      <td>82</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413</td>
      <td>132</td>
      <td>5170</td>
      <td>111</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087</td>
      <td>49</td>
      <td>4911</td>
      <td>127</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173</td>
      <td>315</td>
      <td>4749</td>
      <td>109</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Akwa Ibom</td>
      <td>4659</td>
      <td>29</td>
      <td>4586</td>
      <td>44</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Kwara</td>
      <td>4640</td>
      <td>401</td>
      <td>4175</td>
      <td>64</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Osun</td>
      <td>3311</td>
      <td>36</td>
      <td>3183</td>
      <td>92</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>3307</td>
      <td>83</td>
      <td>3158</td>
      <td>66</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Enugu</td>
      <td>2952</td>
      <td>13</td>
      <td>2910</td>
      <td>29</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Anambra</td>
      <td>2825</td>
      <td>46</td>
      <td>2760</td>
      <td>19</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Imo</td>
      <td>2648</td>
      <td>8</td>
      <td>2582</td>
      <td>58</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Katsina</td>
      <td>2418</td>
      <td>0</td>
      <td>2381</td>
      <td>37</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Nasarawa</td>
      <td>2738</td>
      <td>354</td>
      <td>2345</td>
      <td>39</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDCsorted= NCDCsorted[0:10]
```


```python
NCDCsorted.groupby(['States Affected'])['No Discharged'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_151_1.png)
    



```python
CovidNigsorted = CovidNig.sort_values("No. Discharged", ascending=False)
```


```python
CovidNigsorted.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4262</td>
      <td>280</td>
      <td>3948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Rivers</td>
      <td>3279</td>
      <td>232</td>
      <td>2987</td>
      <td>60</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>2768</td>
      <td>52</td>
      <td>2603</td>
      <td>113</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>2382</td>
      <td>174</td>
      <td>2175</td>
      <td>33</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Kano</td>
      <td>2032</td>
      <td>198</td>
      <td>1778</td>
      <td>56</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Delta</td>
      <td>1843</td>
      <td>57</td>
      <td>1737</td>
      <td>49</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ondo</td>
      <td>1793</td>
      <td>62</td>
      <td>1690</td>
      <td>41</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Enugu</td>
      <td>1376</td>
      <td>34</td>
      <td>1321</td>
      <td>21</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Katsina</td>
      <td>1405</td>
      <td>214</td>
      <td>1167</td>
      <td>24</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Kwara</td>
      <td>1296</td>
      <td>171</td>
      <td>1094</td>
      <td>31</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ebonyi</td>
      <td>1091</td>
      <td>24</td>
      <td>1037</td>
      <td>30</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>1164</td>
      <td>183</td>
      <td>950</td>
      <td>31</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Abia</td>
      <td>980</td>
      <td>25</td>
      <td>945</td>
      <td>10</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Osun</td>
      <td>979</td>
      <td>20</td>
      <td>937</td>
      <td>22</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Bauchi</td>
      <td>897</td>
      <td>108</td>
      <td>775</td>
      <td>14</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Borno</td>
      <td>778</td>
      <td>37</td>
      <td>705</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidNigSplot = CovidNigsorted[0:10]
```


```python
CovidNigSplot.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4262</td>
      <td>280</td>
      <td>3948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidNigsorted.groupby(['States Affected'])['No. Discharged'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_156_1.png)
    



```python
CovidNigSplot.groupby(['States Affected'])['No. Discharged'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_157_1.png)
    


## Summary of the first 4 plots on Top 10 Discharged Cases
The graph of ploting the top 10 states in Nigeria with Covid cases via Lab confrimation. 
This can be done using two dataframes: 
    1. NCDC which is the dataframe scrapped from the NCDC website and 
    2. CovidNig which is the dataframe from the external dataframe.

Using this two dataframe will give room for comparison and drawing of inferences.

## Details of Plots
Plot1 and 2= the graph is a bar chart showing the mean value of the No of Case in each states using NCDC and CovidNig. 
The top 10 states in NCDC are: Lagos, FCT, Rivers, Kaduna, Plateau,Oyo, Edo, Ogun, Delta and Kano. and CovidNig are: Lagos, FCT, Kaduna, Plateau, Oyo, Rivers, Edo, Ogun, Kano and Delta.

Plot3 and 4= these bar charts are just to show the Top10 states more explicitly.

## Inference
-It can be said that the Top 2 states in both dataFrames are Lagos and FCT. With Lagos ranking first in both dataframes. Which means Lagos and FCT has highest discharged.
-Discharged rate of states like Rivers, Kaduna and Plateau weren't constant in the two differnt dataframes.
which will put one a state of which data source is the most accurate. 
-The bottom region in both data sources showed that Ogun, Kano and Delta evening though the position of Kano and Delta 
interchanged in NCDC and CovidNig data sources.


```python
#Plotting the top 10 Death cases
```


```python
#First arranging NCDC and CovidNig Death records in descending order
```


```python
NCDCdeaths = NCDC.sort_values("No of Deaths", ascending=False)
```


```python
NCDCdeaths.head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707</td>
      <td>11</td>
      <td>7375</td>
      <td>321</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232</td>
      <td>1</td>
      <td>10029</td>
      <td>202</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087</td>
      <td>49</td>
      <td>4911</td>
      <td>127</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413</td>
      <td>132</td>
      <td>5170</td>
      <td>111</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173</td>
      <td>315</td>
      <td>4749</td>
      <td>109</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Osun</td>
      <td>3311</td>
      <td>36</td>
      <td>3183</td>
      <td>92</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810</td>
      <td>11</td>
      <td>5717</td>
      <td>82</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>3307</td>
      <td>83</td>
      <td>3158</td>
      <td>66</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Kwara</td>
      <td>4640</td>
      <td>401</td>
      <td>4175</td>
      <td>64</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Imo</td>
      <td>2648</td>
      <td>8</td>
      <td>2582</td>
      <td>58</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidNigdeaths = CovidNig.sort_values("No. of Deaths", ascending=False)
```


```python
CovidNigdeaths.head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>2768</td>
      <td>52</td>
      <td>2603</td>
      <td>113</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Rivers</td>
      <td>3279</td>
      <td>232</td>
      <td>2987</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Kano</td>
      <td>2032</td>
      <td>198</td>
      <td>1778</td>
      <td>56</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Delta</td>
      <td>1843</td>
      <td>57</td>
      <td>1737</td>
      <td>49</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ondo</td>
      <td>1793</td>
      <td>62</td>
      <td>1690</td>
      <td>41</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Borno</td>
      <td>778</td>
      <td>37</td>
      <td>705</td>
      <td>36</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Plateau</td>
      <td>4262</td>
      <td>280</td>
      <td>3948</td>
      <td>34</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>2382</td>
      <td>174</td>
      <td>2175</td>
      <td>33</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Kwara</td>
      <td>1296</td>
      <td>171</td>
      <td>1094</td>
      <td>31</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>1164</td>
      <td>183</td>
      <td>950</td>
      <td>31</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Ebonyi</td>
      <td>1091</td>
      <td>24</td>
      <td>1037</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Sorting out the Top 10 states with Death cases from both DataFrame
```


```python
NCDCdea_sorted= NCDCdeaths[0:10]
```


```python
NCDCdea_sorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707</td>
      <td>11</td>
      <td>7375</td>
      <td>321</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232</td>
      <td>1</td>
      <td>10029</td>
      <td>202</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087</td>
      <td>49</td>
      <td>4911</td>
      <td>127</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413</td>
      <td>132</td>
      <td>5170</td>
      <td>111</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173</td>
      <td>315</td>
      <td>4749</td>
      <td>109</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Osun</td>
      <td>3311</td>
      <td>36</td>
      <td>3183</td>
      <td>92</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
  </tbody>
</table>
</div>




```python
Covid_dea_sorted= CovidNigdeaths[0:10]
```


```python
Covid_dea_sorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No. of Cases (Lab Confirmed)</th>
      <th>No. of Cases (on admission)</th>
      <th>No. Discharged</th>
      <th>No. of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>26708</td>
      <td>2435</td>
      <td>24037</td>
      <td>236</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>2768</td>
      <td>52</td>
      <td>2603</td>
      <td>113</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>9627</td>
      <td>2840</td>
      <td>6694</td>
      <td>93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Rivers</td>
      <td>3279</td>
      <td>232</td>
      <td>2987</td>
      <td>60</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Kano</td>
      <td>2032</td>
      <td>198</td>
      <td>1778</td>
      <td>56</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Delta</td>
      <td>1843</td>
      <td>57</td>
      <td>1737</td>
      <td>49</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kaduna</td>
      <td>4504</td>
      <td>579</td>
      <td>3877</td>
      <td>48</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Oyo</td>
      <td>3788</td>
      <td>368</td>
      <td>3374</td>
      <td>46</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Ondo</td>
      <td>1793</td>
      <td>62</td>
      <td>1690</td>
      <td>41</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Borno</td>
      <td>778</td>
      <td>37</td>
      <td>705</td>
      <td>36</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Ploting the Graphs of Top 10 states via the two dataframes
```


```python
NCDCdea_sorted.groupby(['States Affected'])['No of Deaths'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_171_1.png)
    



```python
Covid_dea_sorted.groupby(['States Affected'])['No. of Deaths'].mean().plot.bar()
```




    <AxesSubplot:xlabel='States Affected'>




    
![png](output_172_1.png)
    


### Summary of the 2 plots on Top 10 Death Cases
The graph of ploting the top 10 states in Nigeria with Covid cases via Lab confrimation. This can be done using two dataframes: 1. NCDC which is the dataframe scrapped from the NCDC website and 2. CovidNig which is the dataframe from the external dataframe.

Using this two dataframe will give room for comparison and drawing of inferences.

### Details of Plots
Plot1 and 2= the graph is a bar chart showing the mean value of the Number of death Case in each states using NCDC and CovidNig. The top 10 states with high Death casualities in NCDC are: Lagos, Edo, FCT, Oyo, Rivers, Kano, Delta, Ondo, Osun and Kaduna. and CovidNig are: Lagos, Edo, FCT, Rivers, Kano, Delta, Kaduna, Oyo, Ondo and Borno respectively.

### Inference
- It can be said that most of the states with high lab confirmation cases has high death casualities.
- Also, the data on the CovidNig wasn't consistent with the NCDC data. As Borno state is part of the top 10 states with death casuality on the CovidNig dataframe


```python
#Generating a line plot for the total daily confirmed, recovered and death cases in Nigeria
```


```python
#Ploting using CoNig, ReNig and DeNig as the total daily confirmed, recovered and death cases in Nigeria
```


```python
CoNig.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>859</th>
      <td>2022-05-30</td>
      <td>256028</td>
    </tr>
    <tr>
      <th>860</th>
      <td>2022-05-31</td>
      <td>256028</td>
    </tr>
    <tr>
      <th>861</th>
      <td>2022-06-01</td>
      <td>256028</td>
    </tr>
    <tr>
      <th>862</th>
      <td>2022-06-02</td>
      <td>256113</td>
    </tr>
    <tr>
      <th>863</th>
      <td>2022-06-03</td>
      <td>256113</td>
    </tr>
    <tr>
      <th>864</th>
      <td>2022-06-04</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>865</th>
      <td>2022-06-05</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>866</th>
      <td>2022-06-06</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>867</th>
      <td>2022-06-07</td>
      <td>256227</td>
    </tr>
    <tr>
      <th>868</th>
      <td>2022-06-08</td>
      <td>256227</td>
    </tr>
  </tbody>
</table>
</div>




```python
import seaborn as sbn
```


```python
import matplotlib.pyplot as plt
```


```python
sns.catplot(x='Cases', y='Date', aspect= 8, kind= 'point', data = CoNig)
```




    <seaborn.axisgrid.FacetGrid at 0x1895c36f970>




    
![png](output_179_1.png)
    



```python
fig = plt.figure(figsize=(20,10))
ax = fig.add_subplot()
ax.plot(CoNig.Date, CoNig.Cases)
```




    [<matplotlib.lines.Line2D at 0x1895dc1d370>]




    
![png](output_180_1.png)
    



```python
#Plotting graph of Total daily Recovery using ReNig Dataset
```


```python
fig = plt.figure(figsize=(20,10))
ax = fig.add_subplot()
ax.plot(ReNig.Date, ReNig.Cases)
```




    [<matplotlib.lines.Line2D at 0x1895dc8b610>]




    
![png](output_182_1.png)
    



```python
#Plotting the graphs of total death cases in Nigeria usinf DeNig Dataset
```


```python
fig = plt.figure(figsize=(20,10))
ax = fig.add_subplot()
ax.plot(DeNig.Date, DeNig.Cases)
```




    [<matplotlib.lines.Line2D at 0x1895dc622e0>]




    
![png](output_184_1.png)
    


### Summary of the 3 plot graphs on Total Confirmed, Discharged, Recovery and Death Cases.

#### Plot 1: A line graph of total confirmed Cases
This graphs shows that is a daily increase in the total confirm cases. It can also be infered that from April,2022 the number of cases confirmed seemed constant or stead.

#### Plot 2: A line graph of total recovery Cases
The daily revcovery cases was on a rise between April 2020 till July 2021 i.e the numbers of people that recovered from Covid-19 was on a rise between this peroid. A sharp drop to nearly zero from September 2021 and was constistent at that level.

#### Plot 3: A line graph of total death Cases
The plot of death cases is quite similar to that of confirmed cases, as there is a consistent increase in the number of recorded death cases in Nigeria as the date goes by.


# Todo F

####  Determine the daily infection rate, you can use the Pandas diff method to find the derivate of the total cases. Then plot the line graph


```python
#Dataset will be use is the confirmed cases (CoNig), where there will be row 1 will be removed from row 2 and so on
```


```python
CoNig.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2020-01-22</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2020-01-23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2020-01-24</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2020-01-25</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2020-01-26</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
DIR = CoNig.diff()
```


```python
DIR
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaT</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>864</th>
      <td>1 days</td>
      <td>35</td>
    </tr>
    <tr>
      <th>865</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>866</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>867</th>
      <td>1 days</td>
      <td>79</td>
    </tr>
    <tr>
      <th>868</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>869 rows × 2 columns</p>
</div>




```python
#Plotting the Line graphs of the Daily Infection Rate
```


```python
fig = plt.figure(figsize=(20,10))
ax = fig.add_subplot()
ax.plot(DIR.Cases)
```




    [<matplotlib.lines.Line2D at 0x1895dc05f70>]




    
![png](output_192_1.png)
    


# TODO G 

### Calculate maximum infection rate for a day (Number of new cases)


```python
#Arranging the Daily infection rate in Descending order to find the maximum number of cases of Infection rate
```


```python
DIRsorted = DIR.sort_values("Cases", ascending=False)
```


```python
DIRsorted
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>700</th>
      <td>1 days</td>
      <td>6158</td>
    </tr>
    <tr>
      <th>367</th>
      <td>1 days</td>
      <td>2464</td>
    </tr>
    <tr>
      <th>365</th>
      <td>1 days</td>
      <td>1964</td>
    </tr>
    <tr>
      <th>701</th>
      <td>1 days</td>
      <td>1940</td>
    </tr>
    <tr>
      <th>374</th>
      <td>1 days</td>
      <td>1883</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>577</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>603</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>868</th>
      <td>1 days</td>
      <td>0</td>
    </tr>
    <tr>
      <th>812</th>
      <td>1 days</td>
      <td>-30</td>
    </tr>
    <tr>
      <th>0</th>
      <td>NaT</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>869 rows × 2 columns</p>
</div>



#### it is shown that the highest number of cases is 6158(new cases) in a day on index number 700.

so what date falls on the index 700?


```python
#Checking the confirm cases dataset CoNig to get the date on index 700
```


```python
CoNig.loc[700]
```




    Date     2021-12-22 00:00:00
    Cases                 231413
    Name: 700, dtype: object




```python
CoNig.tail(169)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>Cases</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>700</th>
      <td>2021-12-22</td>
      <td>231413</td>
    </tr>
    <tr>
      <th>701</th>
      <td>2021-12-23</td>
      <td>233353</td>
    </tr>
    <tr>
      <th>702</th>
      <td>2021-12-24</td>
      <td>234709</td>
    </tr>
    <tr>
      <th>703</th>
      <td>2021-12-25</td>
      <td>236014</td>
    </tr>
    <tr>
      <th>704</th>
      <td>2021-12-26</td>
      <td>237561</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>864</th>
      <td>2022-06-04</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>865</th>
      <td>2022-06-05</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>866</th>
      <td>2022-06-06</td>
      <td>256148</td>
    </tr>
    <tr>
      <th>867</th>
      <td>2022-06-07</td>
      <td>256227</td>
    </tr>
    <tr>
      <th>868</th>
      <td>2022-06-08</td>
      <td>256227</td>
    </tr>
  </tbody>
</table>
<p>169 rows × 2 columns</p>
</div>



### The date with the highest new cases i.e maximum daily infection rate is 2021-12-22 with 231413 total recorded case of which 6158 infections per day

# TODO H

Determine the relationship between the external dataset and the NCDC COVID-19 dataset. Here you will generate a line plot of top 10 confirmed cases and the overall community vulnerability index on the same axis. From the graph, explain your observation.
Steps


```python
#Loading Datasets
```


```python
NCDC.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641</td>
      <td>1,810</td>
      <td>98062</td>
      <td>769</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763</td>
      <td>63</td>
      <td>28451</td>
      <td>249</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826</td>
      <td>127</td>
      <td>16545</td>
      <td>154</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314</td>
      <td>7</td>
      <td>11218</td>
      <td>89</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258</td>
      <td>2</td>
      <td>10181</td>
      <td>75</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidOther.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>states</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>FCT</td>
      <td>North Central</td>
      <td>4865000</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Plateau</td>
      <td>North Central</td>
      <td>4766000</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kwara</td>
      <td>North Central</td>
      <td>3524000</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nassarawa</td>
      <td>North Central</td>
      <td>2783000</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Niger</td>
      <td>North Central</td>
      <td>6260000</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.84</td>
    </tr>
  </tbody>
</table>
</div>




```python
CovidOther.rename(columns = {'states':'States Affected'}, inplace = True)
```


```python
CovidOther.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>FCT</td>
      <td>North Central</td>
      <td>4865000</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Plateau</td>
      <td>North Central</td>
      <td>4766000</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Kwara</td>
      <td>North Central</td>
      <td>3524000</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Nassarawa</td>
      <td>North Central</td>
      <td>2783000</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Niger</td>
      <td>North Central</td>
      <td>6260000</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.84</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Merging the two datasets together on a similar column
```


```python
NCDC_Other = NCDC.merge(CovidOther, how= 'outer')
```


```python
NCDC_Other
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641.0</td>
      <td>1,810</td>
      <td>98062.0</td>
      <td>769.0</td>
      <td>South West</td>
      <td>13992000.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.3</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763.0</td>
      <td>63</td>
      <td>28451.0</td>
      <td>249.0</td>
      <td>North Central</td>
      <td>4865000.0</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826.0</td>
      <td>127</td>
      <td>16545.0</td>
      <td>154.0</td>
      <td>South South</td>
      <td>7763000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314.0</td>
      <td>7</td>
      <td>11218.0</td>
      <td>89.0</td>
      <td>North West</td>
      <td>9227000.0</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.4</td>
      <td>0.86</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258.0</td>
      <td>2</td>
      <td>10181.0</td>
      <td>75.0</td>
      <td>North Central</td>
      <td>4766000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232.0</td>
      <td>1</td>
      <td>10029.0</td>
      <td>202.0</td>
      <td>South West</td>
      <td>8737000.0</td>
      <td>0.2</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707.0</td>
      <td>11</td>
      <td>7375.0</td>
      <td>321.0</td>
      <td>South South</td>
      <td>4705000.0</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>1.09</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810.0</td>
      <td>11</td>
      <td>5717.0</td>
      <td>82.0</td>
      <td>South West</td>
      <td>5878000.0</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.2</td>
      <td>1.07</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413.0</td>
      <td>132</td>
      <td>5170.0</td>
      <td>111.0</td>
      <td>South South</td>
      <td>6303000.0</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.2</td>
      <td>1.0</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>1.08</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173.0</td>
      <td>315</td>
      <td>4749.0</td>
      <td>109.0</td>
      <td>South West</td>
      <td>5185000.0</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>1.04</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Kano</td>
      <td>5087.0</td>
      <td>49</td>
      <td>4911.0</td>
      <td>127.0</td>
      <td>North West</td>
      <td>14726000.0</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Akwa Ibom</td>
      <td>4659.0</td>
      <td>29</td>
      <td>4586.0</td>
      <td>44.0</td>
      <td>South East</td>
      <td>6093000.0</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.7</td>
      <td>0.6</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.1</td>
      <td>1.01</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Kwara</td>
      <td>4640.0</td>
      <td>401</td>
      <td>4175.0</td>
      <td>64.0</td>
      <td>North Central</td>
      <td>3524000.0</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Osun</td>
      <td>3311.0</td>
      <td>36</td>
      <td>3183.0</td>
      <td>92.0</td>
      <td>South West</td>
      <td>5252000.0</td>
      <td>0.0</td>
      <td>0.7</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.0</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.2</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Gombe</td>
      <td>3307.0</td>
      <td>83</td>
      <td>3158.0</td>
      <td>66.0</td>
      <td>North East</td>
      <td>3692000.0</td>
      <td>1.0</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.9</td>
      <td>0.9</td>
      <td>0.3</td>
      <td>0.8</td>
      <td>0.7</td>
      <td>0.83</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Enugu</td>
      <td>2952.0</td>
      <td>13</td>
      <td>2910.0</td>
      <td>29.0</td>
      <td>South East</td>
      <td>4801000.0</td>
      <td>0.2</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.0</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.4</td>
      <td>0.1</td>
      <td>1.14</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Anambra</td>
      <td>2825.0</td>
      <td>46</td>
      <td>2760.0</td>
      <td>19.0</td>
      <td>South East</td>
      <td>6050000.0</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>1.0</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>1.08</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Nasarawa</td>
      <td>2738.0</td>
      <td>354</td>
      <td>2345.0</td>
      <td>39.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Imo</td>
      <td>2648.0</td>
      <td>8</td>
      <td>2582.0</td>
      <td>58.0</td>
      <td>South East</td>
      <td>6018000.0</td>
      <td>0.4</td>
      <td>1.0</td>
      <td>0.9</td>
      <td>0.0</td>
      <td>0.4</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.0</td>
      <td>1.12</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Katsina</td>
      <td>2418.0</td>
      <td>0</td>
      <td>2381.0</td>
      <td>37.0</td>
      <td>North West</td>
      <td>8713000.0</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Abia</td>
      <td>2177.0</td>
      <td>1</td>
      <td>2142.0</td>
      <td>34.0</td>
      <td>South East</td>
      <td>4190000.0</td>
      <td>0.2</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.9</td>
      <td>0.2</td>
      <td>0.0</td>
      <td>1.14</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Benue</td>
      <td>2129.0</td>
      <td>340</td>
      <td>1764.0</td>
      <td>25.0</td>
      <td>North Central</td>
      <td>6376000.0</td>
      <td>0.5</td>
      <td>0.7</td>
      <td>0.5</td>
      <td>0.7</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.91</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Ebonyi</td>
      <td>2064.0</td>
      <td>28</td>
      <td>2004.0</td>
      <td>32.0</td>
      <td>South South</td>
      <td>3192000.0</td>
      <td>0.6</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.1</td>
      <td>0.7</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Ekiti</td>
      <td>2006.0</td>
      <td>52</td>
      <td>1926.0</td>
      <td>28.0</td>
      <td>South West</td>
      <td>3593000.0</td>
      <td>0.3</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>1.03</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Bauchi</td>
      <td>1967.0</td>
      <td>1</td>
      <td>1942.0</td>
      <td>24.0</td>
      <td>North East</td>
      <td>7270000.0</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Borno</td>
      <td>1629.0</td>
      <td>5</td>
      <td>1580.0</td>
      <td>44.0</td>
      <td>North East</td>
      <td>6651000.0</td>
      <td>0.9</td>
      <td>0.3</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>0.7</td>
      <td>0.9</td>
      <td>0.89</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Taraba</td>
      <td>1473.0</td>
      <td>62</td>
      <td>1377.0</td>
      <td>34.0</td>
      <td>North East</td>
      <td>3387000.0</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.8</td>
      <td>0.9</td>
      <td>0.5</td>
      <td>0.0</td>
      <td>0.7</td>
      <td>0.9</td>
      <td>0.86</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Bayelsa</td>
      <td>1321.0</td>
      <td>1</td>
      <td>1292.0</td>
      <td>28.0</td>
      <td>South South</td>
      <td>2606000.0</td>
      <td>0.5</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.5</td>
      <td>0.2</td>
      <td>0.7</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Adamawa</td>
      <td>1203.0</td>
      <td>68</td>
      <td>1103.0</td>
      <td>32.0</td>
      <td>North East</td>
      <td>4672000.0</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.7</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.6</td>
      <td>0.94</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Niger</td>
      <td>1148.0</td>
      <td>130</td>
      <td>998.0</td>
      <td>20.0</td>
      <td>North Central</td>
      <td>6260000.0</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.8</td>
      <td>0.84</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Cross River</td>
      <td>842.0</td>
      <td>8</td>
      <td>809.0</td>
      <td>25.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Sokoto</td>
      <td>818.0</td>
      <td>0</td>
      <td>790.0</td>
      <td>28.0</td>
      <td>North West</td>
      <td>5612000.0</td>
      <td>0.9</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.7</td>
      <td>0.3</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.89</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Jigawa</td>
      <td>669.0</td>
      <td>2</td>
      <td>649.0</td>
      <td>18.0</td>
      <td>North West</td>
      <td>6435000.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.0</td>
      <td>0.7</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.92</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Yobe</td>
      <td>609.0</td>
      <td>0</td>
      <td>600.0</td>
      <td>9.0</td>
      <td>North East</td>
      <td>3723000.0</td>
      <td>1.0</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>1.0</td>
      <td>0.5</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>1.0</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Kebbi</td>
      <td>480.0</td>
      <td>10</td>
      <td>454.0</td>
      <td>16.0</td>
      <td>North West</td>
      <td>4968000.0</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>0.4</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.9</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Zamfara</td>
      <td>375.0</td>
      <td>0</td>
      <td>366.0</td>
      <td>9.0</td>
      <td>North West</td>
      <td>4974000.0</td>
      <td>0.9</td>
      <td>0.2</td>
      <td>0.1</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>1.0</td>
      <td>0.9</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Kogi</td>
      <td>5.0</td>
      <td>0</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>North Central</td>
      <td>4970000.0</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.2</td>
      <td>0.5</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.87</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Nassarawa</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>North Central</td>
      <td>2783000.0</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Cross river</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>South South</td>
      <td>4272000.0</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.98</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Create a new dataframe for plotting. This DataFrame will contain top 10 states in terms of confirmed cases i.e sort by confirmed cases.
```


```python
Othertop10 = NCDC_Other.nlargest(10, "No of cases lab")
```


```python
Othertop10
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641.0</td>
      <td>1,810</td>
      <td>98062.0</td>
      <td>769.0</td>
      <td>South West</td>
      <td>13992000.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.3</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763.0</td>
      <td>63</td>
      <td>28451.0</td>
      <td>249.0</td>
      <td>North Central</td>
      <td>4865000.0</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826.0</td>
      <td>127</td>
      <td>16545.0</td>
      <td>154.0</td>
      <td>South South</td>
      <td>7763000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314.0</td>
      <td>7</td>
      <td>11218.0</td>
      <td>89.0</td>
      <td>North West</td>
      <td>9227000.0</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.4</td>
      <td>0.86</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258.0</td>
      <td>2</td>
      <td>10181.0</td>
      <td>75.0</td>
      <td>North Central</td>
      <td>4766000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232.0</td>
      <td>1</td>
      <td>10029.0</td>
      <td>202.0</td>
      <td>South West</td>
      <td>8737000.0</td>
      <td>0.2</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707.0</td>
      <td>11</td>
      <td>7375.0</td>
      <td>321.0</td>
      <td>South South</td>
      <td>4705000.0</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>1.09</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810.0</td>
      <td>11</td>
      <td>5717.0</td>
      <td>82.0</td>
      <td>South West</td>
      <td>5878000.0</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.2</td>
      <td>1.07</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413.0</td>
      <td>132</td>
      <td>5170.0</td>
      <td>111.0</td>
      <td>South South</td>
      <td>6303000.0</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.2</td>
      <td>1.0</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>1.08</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173.0</td>
      <td>315</td>
      <td>4749.0</td>
      <td>109.0</td>
      <td>South West</td>
      <td>5185000.0</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>1.04</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plotting the graphs
```


```python
Othertop10.rename(columns = {'States Affected':'States'}, inplace = True)
```


```python
Othertop10.States
```




    0      Lagos
    1        FCT
    2     Rivers
    3     Kaduna
    4    Plateau
    5        Oyo
    6        Edo
    7       Ogun
    8      Delta
    9       Ondo
    Name: States, dtype: object




```python
fig = plt.figure(figsize=(20,10))
ax1 = fig.add_subplot()
ax1.plot(Othertop10.States, Other_top10.No of cases lab)
ax1.set_ylabel('Confirmed Cases')

ax2 = ax1.twinx()
ax2.plot(Othertop10.States, Other_top10.Overall CCVI Index, 'r-')
ax2.set_ylabel('Overall community vulnerability index', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
```


      File "<ipython-input-200-0bb021e3e3ad>", line 3
        ax1.plot(Othertop10.States, Other_top10.No of cases lab)
                                                   ^
    SyntaxError: invalid syntax
    



```python
Othertop10.rename(columns = {'No of cases lab':'Confirmed'}, inplace = True)
```


```python
Othertop10.rename(columns = {'Overall CCVI Index':'CCVI'}, inplace = True)
```


```python
fig = plt.figure(figsize=(20,10))
ax1 = fig.add_subplot()
ax1.plot(Othertop10.States, Othertop10.Confirmed)
ax1.set_ylabel('Confirmed Cases')

ax2 = ax1.twinx()
ax2.plot(Othertop10.States, Othertop10.CCVI, 'r-')
ax2.set_ylabel('CCVI', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
```


    
![png](output_220_0.png)
    


#### From the Combine graph
Kadauna state has the heighest community vulnerability index despite having low cases recorded and Lagos state despites having the highest number of confirmed cases has the lowest community vulnerability index. Ondo and Edo has low community vulnerability index and low confirmed cases.

It can be infered that there is no consistent relationship between the two variables i.e confirmed cases and community vulnerability index

# TODO I 

Determine the relationship between the external dataset and the NCDC COVID-19 dataset.


```python
#Generate a regression plot between two variables to visualize the linear relationships - Confirmed Cases and Population Density
```


```python
NCDC_Other.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States Affected</th>
      <th>No of cases lab</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
      <th>region</th>
      <th>Population</th>
      <th>Overall CCVI Index</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641.0</td>
      <td>1,810</td>
      <td>98062.0</td>
      <td>769.0</td>
      <td>South West</td>
      <td>13992000.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.3</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763.0</td>
      <td>63</td>
      <td>28451.0</td>
      <td>249.0</td>
      <td>North Central</td>
      <td>4865000.0</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826.0</td>
      <td>127</td>
      <td>16545.0</td>
      <td>154.0</td>
      <td>South South</td>
      <td>7763000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314.0</td>
      <td>7</td>
      <td>11218.0</td>
      <td>89.0</td>
      <td>North West</td>
      <td>9227000.0</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.4</td>
      <td>0.86</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258.0</td>
      <td>2</td>
      <td>10181.0</td>
      <td>75.0</td>
      <td>North Central</td>
      <td>4766000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
  </tbody>
</table>
</div>




```python
NCDC_Other.rename(columns = {'No of cases lab':'Confirmed'}, inplace = True)
NCDC_Other.rename(columns = {'States Affected':'States'}, inplace = True)
```


```python
NCDC_Other.rename(columns = {'Population Density':'PoPDensity'}, inplace = True)
```


```python
#Plotting the a regression graph of Confirmed Cases (y= Confirmed) against Population density (x= PoPDensity)
```


```python
ax = sns.regplot(x="PoPDensity", y="Confirmed", data=NCDC_Other)
```


    
![png](output_228_0.png)
    


#### Summary o the regression graph

From the graph there is a strong linear relationship between the confirmed cases and the population density

# TODO J

Providing more analyses by extending TODO G & H. Meaning, determine relationships between more features.


```python
NCDC_Other.rename(columns = {'Health System':'Health_System'}, inplace = True)
```


```python
#Plotting the graphs of States showing their Health Systems and Social Economic status
```


```python
NCDC_Other.rename(columns ={'States Affected': 'States'}, inplace = True)
```


```python
NCDC_Other.rename(columns ={'Socio-Economic': 'Socio_Economic'}, inplace = True)
```


```python
fig = plt.figure(figsize=(20,10))
ax1 = fig.add_subplot()
ax1.plot(NCDC_Other.States, NCDC_Other.Health_System)
ax1.set_ylabel('Health System')

ax2 = ax1.twinx()
ax2.plot(NCDC_Other.States, NCDC_Other.Socio_Economic, 'r-')
ax2.set_ylabel('Economic', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
```


    
![png](output_235_0.png)
    



```python
##Plotting the graphs of States showing their Health Systems and Social Economic status using the Top 10 state data
```


```python
Othertop10
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>States</th>
      <th>Confirmed</th>
      <th>No of Cases</th>
      <th>No Discharged</th>
      <th>No of Deaths</th>
      <th>region</th>
      <th>Population</th>
      <th>CCVI</th>
      <th>Age</th>
      <th>Epidemiological</th>
      <th>Fragility</th>
      <th>Health System</th>
      <th>Population Density</th>
      <th>Socio-Economic</th>
      <th>Transport Availability</th>
      <th>Acute IHR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Lagos</td>
      <td>100641.0</td>
      <td>1,810</td>
      <td>98062.0</td>
      <td>769.0</td>
      <td>South West</td>
      <td>13992000.0</td>
      <td>0.0</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.3</td>
      <td>0.1</td>
      <td>1.0</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>1</th>
      <td>FCT</td>
      <td>28763.0</td>
      <td>63</td>
      <td>28451.0</td>
      <td>249.0</td>
      <td>North Central</td>
      <td>4865000.0</td>
      <td>0.3</td>
      <td>0.0</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.79</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Rivers</td>
      <td>16826.0</td>
      <td>127</td>
      <td>16545.0</td>
      <td>154.0</td>
      <td>South South</td>
      <td>7763000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.9</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Kaduna</td>
      <td>11314.0</td>
      <td>7</td>
      <td>11218.0</td>
      <td>89.0</td>
      <td>North West</td>
      <td>9227000.0</td>
      <td>0.7</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.9</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.4</td>
      <td>0.86</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Plateau</td>
      <td>10258.0</td>
      <td>2</td>
      <td>10181.0</td>
      <td>75.0</td>
      <td>North Central</td>
      <td>4766000.0</td>
      <td>0.4</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.8</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>0.5</td>
      <td>0.3</td>
      <td>0.93</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Oyo</td>
      <td>10232.0</td>
      <td>1</td>
      <td>10029.0</td>
      <td>202.0</td>
      <td>South West</td>
      <td>8737000.0</td>
      <td>0.2</td>
      <td>0.7</td>
      <td>0.8</td>
      <td>0.2</td>
      <td>0.8</td>
      <td>0.6</td>
      <td>0.2</td>
      <td>0.3</td>
      <td>1.06</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Edo</td>
      <td>7707.0</td>
      <td>11</td>
      <td>7375.0</td>
      <td>321.0</td>
      <td>South South</td>
      <td>4705000.0</td>
      <td>0.1</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.1</td>
      <td>0.1</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>0.3</td>
      <td>1.09</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Ogun</td>
      <td>5810.0</td>
      <td>11</td>
      <td>5717.0</td>
      <td>82.0</td>
      <td>South West</td>
      <td>5878000.0</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.5</td>
      <td>0.6</td>
      <td>0.6</td>
      <td>0.0</td>
      <td>0.2</td>
      <td>1.07</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Delta</td>
      <td>5413.0</td>
      <td>132</td>
      <td>5170.0</td>
      <td>111.0</td>
      <td>South South</td>
      <td>6303000.0</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>0.7</td>
      <td>0.2</td>
      <td>1.0</td>
      <td>0.6</td>
      <td>0.5</td>
      <td>0.4</td>
      <td>1.08</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Ondo</td>
      <td>5173.0</td>
      <td>315</td>
      <td>4749.0</td>
      <td>109.0</td>
      <td>South West</td>
      <td>5185000.0</td>
      <td>0.1</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.1</td>
      <td>0.3</td>
      <td>0.6</td>
      <td>0.3</td>
      <td>0.3</td>
      <td>1.04</td>
    </tr>
  </tbody>
</table>
</div>




```python
Othertop10.rename(columns = {'Health System':'Health_System'}, inplace = True)
```


```python
Othertop10.rename(columns = {'Population Density':'PoPDensity'}, inplace = True)
```


```python
Othertop10.rename(columns ={'Socio-Economic': 'Socio_Economic'}, inplace = True)
```


```python
fig = plt.figure(figsize=(20,10))
ax1 = fig.add_subplot()
ax1.plot(Othertop10.States, Othertop10.Health_System)
ax1.set_ylabel('Health System')

ax2 = ax1.twinx()
ax2.plot(Othertop10.States, Othertop10.Socio_Economic, 'r-')
ax2.set_ylabel('Economic', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
```


    
![png](output_241_0.png)
    


#### There is no major relationship between the Socio-Economic status of a state and their Health system. For example Oyo has low socio- economic status and high health system, compare to Edo state which was reverse. Only few states like Delta, Ondo and Kaduna had a direct relationship between the two variables


```python
#Plotting a Regression graph between Epideology and Fragility using the NCDC data
```


```python
ax = sns.regplot(x="Epidemiological", y="Fragility", data=NCDC_Other)
```


    
![png](output_244_0.png)
    


#### There isn't any linear relationship between the Fragility and Epidemiological status of a state. It can be infered that they are independent of one another

# TODO L

Determine the effect of the Pandemic on the economy. Via comparing the Real GDP value Pre-COVID-19 with Real GDP in 2020 (COVID-19 Period, especially Q2 2020)


```python
RealGDP
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Q1</th>
      <th>Q2</th>
      <th>Q3</th>
      <th>Q4</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2014</td>
      <td>15438679.50</td>
      <td>16084622.31</td>
      <td>17479127.58</td>
      <td>18150356.45</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015</td>
      <td>16050601.38</td>
      <td>16463341.91</td>
      <td>17976234.59</td>
      <td>18533752.07</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016</td>
      <td>15943714.54</td>
      <td>16218542.41</td>
      <td>17555441.69</td>
      <td>18213537.29</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017</td>
      <td>15797965.83</td>
      <td>16334719.27</td>
      <td>17760228.17</td>
      <td>18598067.07</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2018</td>
      <td>16096654.19</td>
      <td>16580508.07</td>
      <td>18081342.10</td>
      <td>19041437.59</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2019</td>
      <td>16434552.65</td>
      <td>16931434.89</td>
      <td>18494114.17</td>
      <td>19530000.00</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2020</td>
      <td>16740000.00</td>
      <td>15890000.00</td>
      <td>17820000.00</td>
      <td>0.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
RealGDP_Plot = pd.melt(RealGDP, col_level=0, id_vars=['Year'], value_vars=['Q1', 'Q2', 'Q3', 'Q4'])
```


```python
RealGDP_Plot
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>variable</th>
      <th>value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2014</td>
      <td>Q1</td>
      <td>15438679.50</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2015</td>
      <td>Q1</td>
      <td>16050601.38</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016</td>
      <td>Q1</td>
      <td>15943714.54</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017</td>
      <td>Q1</td>
      <td>15797965.83</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2018</td>
      <td>Q1</td>
      <td>16096654.19</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2019</td>
      <td>Q1</td>
      <td>16434552.65</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2020</td>
      <td>Q1</td>
      <td>16740000.00</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2014</td>
      <td>Q2</td>
      <td>16084622.31</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2015</td>
      <td>Q2</td>
      <td>16463341.91</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2016</td>
      <td>Q2</td>
      <td>16218542.41</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2017</td>
      <td>Q2</td>
      <td>16334719.27</td>
    </tr>
    <tr>
      <th>11</th>
      <td>2018</td>
      <td>Q2</td>
      <td>16580508.07</td>
    </tr>
    <tr>
      <th>12</th>
      <td>2019</td>
      <td>Q2</td>
      <td>16931434.89</td>
    </tr>
    <tr>
      <th>13</th>
      <td>2020</td>
      <td>Q2</td>
      <td>15890000.00</td>
    </tr>
    <tr>
      <th>14</th>
      <td>2014</td>
      <td>Q3</td>
      <td>17479127.58</td>
    </tr>
    <tr>
      <th>15</th>
      <td>2015</td>
      <td>Q3</td>
      <td>17976234.59</td>
    </tr>
    <tr>
      <th>16</th>
      <td>2016</td>
      <td>Q3</td>
      <td>17555441.69</td>
    </tr>
    <tr>
      <th>17</th>
      <td>2017</td>
      <td>Q3</td>
      <td>17760228.17</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2018</td>
      <td>Q3</td>
      <td>18081342.10</td>
    </tr>
    <tr>
      <th>19</th>
      <td>2019</td>
      <td>Q3</td>
      <td>18494114.17</td>
    </tr>
    <tr>
      <th>20</th>
      <td>2020</td>
      <td>Q3</td>
      <td>17820000.00</td>
    </tr>
    <tr>
      <th>21</th>
      <td>2014</td>
      <td>Q4</td>
      <td>18150356.45</td>
    </tr>
    <tr>
      <th>22</th>
      <td>2015</td>
      <td>Q4</td>
      <td>18533752.07</td>
    </tr>
    <tr>
      <th>23</th>
      <td>2016</td>
      <td>Q4</td>
      <td>18213537.29</td>
    </tr>
    <tr>
      <th>24</th>
      <td>2017</td>
      <td>Q4</td>
      <td>18598067.07</td>
    </tr>
    <tr>
      <th>25</th>
      <td>2018</td>
      <td>Q4</td>
      <td>19041437.59</td>
    </tr>
    <tr>
      <th>26</th>
      <td>2019</td>
      <td>Q4</td>
      <td>19530000.00</td>
    </tr>
    <tr>
      <th>27</th>
      <td>2020</td>
      <td>Q4</td>
      <td>0.00</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Plotting the Bar chart
```


```python
list(RealGDP_Plot)
```




    ['Year', 'variable', 'value']




```python
RealGDP_Plot.groupby(['Year'])['variable','value'].plot.bar()
```




    Year
    2014    AxesSubplot(0.08,0.07;0.87x0.81)
    2015    AxesSubplot(0.08,0.07;0.87x0.81)
    2016    AxesSubplot(0.08,0.07;0.87x0.81)
    2017    AxesSubplot(0.08,0.07;0.87x0.81)
    2018    AxesSubplot(0.08,0.07;0.87x0.81)
    2019    AxesSubplot(0.08,0.07;0.87x0.81)
    2020    AxesSubplot(0.08,0.07;0.87x0.81)
    dtype: object




    
![png](output_252_1.png)
    



    
![png](output_252_2.png)
    



    
![png](output_252_3.png)
    



    
![png](output_252_4.png)
    



    
![png](output_252_5.png)
    



    
![png](output_252_6.png)
    



    
![png](output_252_7.png)
    



```python
Graph = sns.barplot(x='Year', y='value', hue='variable', data= RealGDP_Plot)
```


    
![png](output_253_0.png)
    



```python
sns.barplot(x='Year', y='value', hue='variable', data= RealGDP_Plot).axhline(y=15890000.00)
```




    <matplotlib.lines.Line2D at 0x189616e0d00>




    
![png](output_254_1.png)
    


# Summary of the Bar Plots

#### There are 2 main plots. The First Bar chart which is a group of Seven (7) individual plots: shows the Real GDP of Q1 to Q4 of each year standling alone. The Second Bar Chart which is the main task, showes all these 7 bar charts in 1-Big bar chart with colour differentiating Q1 - Q4 and drawing an horizontal comparison line.

#### Inference drawn From the 2nd Bar Chart
1. Generally from 2014 till 2019 the GDP has been increasing in each quater from Q1 to Q4. However, the case was different in the year 2020 while the Q2 was lower than her Q1.

2. Comparing the GDP of 2020 with the other previous years it can be seen that the Q2 GDP of 2015 - 2019 are higher than 2020 Q2 GDP. And 2014 and 2020's Q2 GDP are the same. It can be said that the economic GDP in Q2 of the country was growing from 2014 till 2019, then fall in 2020 due to the Covid-19 pandemic.


```python

```
